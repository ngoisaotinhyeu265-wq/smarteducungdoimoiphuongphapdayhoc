import React, { useState } from 'react';
import { Award, Lock, CheckCircle, Sparkles, Filter, Shield, Star, Trophy, ArrowUpRight } from 'lucide-react';
import { Badge, BadgeCategory, BadgeTier, Student } from '../../types';
import { sounds } from '../../lib/audio';

interface BadgeCollectionProps {
  badges: Badge[];
  currentStudent: Student;
  onEquipBadge: (badgeId: string) => void;
  onClaimBadgeReward?: (badge: Badge) => void;
}

export default function BadgeCollection({
  badges,
  currentStudent,
  onEquipBadge,
  onClaimBadgeReward
}: BadgeCollectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);

  const categories: { id: string; label: string; icon: string }[] = [
    { id: 'all', label: 'Tất cả', icon: '🌟' },
    { id: 'learning', label: 'Học tập & Môn học', icon: '📚' },
    { id: 'streak', label: 'Chuỗi ngày học', icon: '🔥' },
    { id: 'quiz', label: 'Trắc nghiệm & Trò chơi', icon: '🎯' },
    { id: 'pet', label: 'Chăm sóc Thú cưng', icon: '🐾' },
    { id: 'stem', label: 'Sáng tạo STEM', icon: '🚀' },
    { id: 'social', label: 'Đồng đội & Bạn bè', icon: '💖' }
  ];

  const filteredBadges = badges.filter(b => {
    if (selectedCategory === 'all') return true;
    return b.category === selectedCategory;
  });

  const unlockedCount = badges.filter(b => b.unlocked).length;

  const getTierColor = (tier: BadgeTier) => {
    switch (tier) {
      case 'bronze':
        return {
          border: 'border-amber-700/40',
          bg: 'bg-amber-900/20',
          badge: 'bg-amber-700/30 text-amber-300 border-amber-600/40',
          label: 'Hạng Đồng 🥉'
        };
      case 'silver':
        return {
          border: 'border-slate-300/40',
          bg: 'bg-slate-800/20',
          badge: 'bg-slate-300/30 text-slate-200 border-slate-200/40',
          label: 'Hạng Bạc 🥈'
        };
      case 'gold':
        return {
          border: 'border-yellow-400/50',
          bg: 'bg-yellow-900/20',
          badge: 'bg-yellow-400/30 text-yellow-300 border-yellow-300/50',
          label: 'Hạng Vàng 🥇'
        };
      case 'diamond':
        return {
          border: 'border-cyan-400/60',
          bg: 'bg-cyan-950/30',
          badge: 'bg-cyan-400/30 text-cyan-200 border-cyan-300/60',
          label: 'Kim Cương 💎'
        };
      case 'mythic':
        return {
          border: 'border-purple-400/60',
          bg: 'bg-purple-950/40',
          badge: 'bg-gradient-to-r from-purple-400/40 to-pink-400/40 text-purple-200 border-purple-300/60',
          label: 'Thần Thoại 👑'
        };
    }
  };

  const handleEquip = (badge: Badge) => {
    sounds.playLevelUp();
    onEquipBadge(badge.id);
  };

  return (
    <div className="w-full space-y-6 select-none animate-fade-in text-left">
      
      {/* Top Banner Stats */}
      <div className="bg-white/10 backdrop-blur-xl p-6 rounded-[32px] border border-white/20 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-white">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-fredoka text-xl md:text-2xl font-extrabold text-yellow-300 flex items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-300" />
              <span>Phòng Truyền Thống Huy Hiệu</span>
            </h2>
            <span className="bg-yellow-400/20 text-yellow-300 border border-yellow-300/40 text-xs font-fredoka font-bold px-3 py-1 rounded-full">
              Đã đạt: {unlockedCount}/{badges.length}
            </span>
          </div>
          <p className="text-xs md:text-sm text-indigo-100 font-medium mt-1">
            Chinh phục các thử thách học tập để mở khóa huy chương danh giá và ghim vào hồ sơ của bạn!
          </p>
        </div>

        {/* Unlocked Progress Bar */}
        <div className="w-full md:w-64 space-y-1.5 bg-white/5 p-3 rounded-2xl border border-white/10">
          <div className="flex justify-between text-xs font-bold text-indigo-100">
            <span>Tiến độ bộ sưu tập</span>
            <span className="text-yellow-300 font-fredoka">{Math.round((unlockedCount / badges.length) * 100)}%</span>
          </div>
          <div className="w-full bg-black/30 h-3 rounded-full overflow-hidden p-[1px]">
            <div 
              className="bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${(unlockedCount / badges.length) * 100}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Category Pills Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map(cat => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => {
                sounds.playClick();
                setSelectedCategory(cat.id);
              }}
              className={`px-4 py-2 rounded-2xl font-fredoka font-bold text-xs whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer
                ${isActive 
                  ? 'bg-yellow-400 text-purple-950 shadow-lg scale-105 border-2 border-white' 
                  : 'bg-white/10 hover:bg-white/20 text-indigo-100 border border-white/15'
                }
              `}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredBadges.map(badge => {
          const tierStyle = getTierColor(badge.tier);
          const isEquipped = currentStudent.equippedBadgeId === badge.id || badge.isEquipped;
          const progressPercent = Math.min(100, Math.round((badge.progress / badge.maxProgress) * 100));

          return (
            <div
              key={badge.id}
              onClick={() => {
                sounds.playClick();
                setSelectedBadge(badge);
              }}
              className={`rounded-[28px] p-5 border backdrop-blur-xl shadow-xl flex flex-col justify-between relative transition-all duration-300 cursor-pointer group hover:-translate-y-1.5
                ${badge.unlocked 
                  ? `${tierStyle.bg} ${tierStyle.border} hover:shadow-2xl` 
                  : 'bg-black/20 border-white/10 opacity-70 hover:opacity-90'
                }
              `}
            >
              {/* Equipped Pin Badge */}
              {isEquipped && (
                <div className="absolute -top-2 -right-2 bg-gradient-to-r from-emerald-400 to-green-500 text-white font-fredoka font-extrabold text-[9px] px-2.5 py-0.5 rounded-full shadow-md border border-white flex items-center gap-1 animate-pulse">
                  <Star className="w-2.5 h-2.5 fill-white" />
                  <span>ĐANG ĐEO</span>
                </div>
              )}

              {/* Badge Icon & Tier */}
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-inner border relative
                    ${badge.unlocked ? 'bg-white/20 border-white/30 group-hover:scale-110 transition-transform' : 'bg-black/40 border-white/10'}
                  `}>
                    {badge.icon}
                    {!badge.unlocked && (
                      <div className="absolute inset-0 bg-black/50 rounded-2xl flex items-center justify-center">
                        <Lock className="w-5 h-5 text-gray-400" />
                      </div>
                    )}
                  </div>

                  <span className={`text-[9px] font-fredoka font-bold px-2 py-0.5 rounded-full border ${tierStyle.badge}`}>
                    {tierStyle.label}
                  </span>
                </div>

                <h4 className="font-fredoka text-sm font-extrabold text-white group-hover:text-yellow-300 transition-colors">
                  {badge.name}
                </h4>
                <p className="text-[11px] text-indigo-200 line-clamp-2 mt-1 leading-relaxed">
                  {badge.description}
                </p>
              </div>

              {/* Progress & Actions */}
              <div className="mt-4 pt-3 border-t border-white/10 space-y-2">
                <div className="flex justify-between text-[10px] font-bold text-indigo-200">
                  <span>{badge.unlocked ? '✅ Đã hoàn thành' : 'Tiến độ'}</span>
                  <span>{badge.progress}/{badge.maxProgress}</span>
                </div>

                <div className="w-full bg-black/30 h-2 rounded-full overflow-hidden p-[0.5px]">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${badge.unlocked ? 'bg-emerald-400' : 'bg-yellow-400'}`}
                    style={{ width: `${progressPercent}%` }}
                  ></div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-yellow-300 font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    +{badge.rewardCoins} xu
                  </span>

                  {badge.unlocked && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEquip(badge);
                      }}
                      className={`text-[10px] font-fredoka font-bold px-2.5 py-1 rounded-xl transition-all cursor-pointer
                        ${isEquipped 
                          ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/40' 
                          : 'bg-white/20 hover:bg-white/30 text-white hover:scale-105'
                        }
                      `}
                    >
                      {isEquipped ? 'Đang ghim' : 'Đeo huy hiệu'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Badge Detail Modal */}
      {selectedBadge && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="w-full max-w-md bg-[#231A54] rounded-[36px] border-2 border-white/25 shadow-2xl p-6 text-white relative">
            <button
              onClick={() => {
                sounds.playClick();
                setSelectedBadge(null);
              }}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-sm font-bold cursor-pointer"
            >
              ✕
            </button>

            <div className="text-center space-y-3">
              <div className="w-20 h-20 mx-auto rounded-3xl bg-white/15 border-2 border-white/30 flex items-center justify-center text-5xl shadow-2xl animate-bounce">
                {selectedBadge.icon}
              </div>

              <div>
                <span className={`text-[10px] font-fredoka font-bold px-3 py-1 rounded-full border ${getTierColor(selectedBadge.tier).badge}`}>
                  {getTierColor(selectedBadge.tier).label}
                </span>
                <h3 className="font-fredoka text-xl font-extrabold text-white mt-2">
                  {selectedBadge.name}
                </h3>
              </div>

              <p className="text-xs text-indigo-100 px-4 leading-relaxed font-medium">
                {selectedBadge.description}
              </p>

              {/* Reward stats */}
              <div className="flex justify-center gap-3 py-2">
                <div className="bg-yellow-400/20 border border-yellow-300/40 px-3.5 py-1.5 rounded-2xl text-xs font-bold text-yellow-300 flex items-center gap-1.5">
                  <Star className="w-4 h-4 fill-yellow-400" />
                  <span>+{selectedBadge.rewardCoins} Xu</span>
                </div>
                <div className="bg-purple-400/20 border border-purple-300/40 px-3.5 py-1.5 rounded-2xl text-xs font-bold text-purple-200 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-purple-300" />
                  <span>+{selectedBadge.rewardXp} XP</span>
                </div>
              </div>

              {selectedBadge.unlocked ? (
                <div className="p-3 bg-emerald-500/20 border border-emerald-400/40 rounded-2xl text-xs text-emerald-200 font-bold">
                  🎉 Bạn đã mở khóa huy hiệu này vào ngày: {selectedBadge.unlockedAt || 'Gần đây'}!
                </div>
              ) : (
                <div className="p-3 bg-white/10 border border-white/15 rounded-2xl text-xs text-indigo-200 font-medium">
                  🔒 Cần hoàn thành: <strong className="text-white">{selectedBadge.progress}/{selectedBadge.maxProgress}</strong> yêu cầu.
                </div>
              )}
            </div>

            <div className="mt-6 flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <button
                onClick={() => setSelectedBadge(null)}
                className="px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-xs font-bold text-indigo-100 cursor-pointer"
              >
                Đóng
              </button>

              {selectedBadge.unlocked && (
                <button
                  onClick={() => {
                    handleEquip(selectedBadge);
                    setSelectedBadge(null);
                  }}
                  className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-yellow-300 to-amber-400 text-purple-950 font-fredoka font-extrabold text-xs shadow-md hover:scale-105 cursor-pointer"
                >
                  Đeo Lên Hồ Sơ
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
