import React, { useState, useEffect } from 'react';
import { 
  Trophy, Star, Award, Target, Heart, Sparkles, 
  UserCheck, Plus, UserPlus, Flame, Shield, ArrowRight,
  RefreshCw
} from 'lucide-react';
import { Student, VirtualPet, Badge, Quest, LeaderboardEntry } from '../../types';
import { 
  INITIAL_STUDENTS, 
  INITIAL_PETS, 
  INITIAL_BADGES, 
  INITIAL_QUESTS, 
  INITIAL_LEADERBOARDS 
} from '../../data/gamificationData';
import { sounds } from '../../lib/audio';
import VirtualPetSanctuary from './VirtualPetSanctuary';
import BadgeCollection from './BadgeCollection';
import QuestsMissions from './QuestsMissions';
import MultiLeaderboards from './MultiLeaderboards';

interface StudentGamificationHubProps {
  onNavigateToGames?: () => void;
  onNavigateToQuestions?: () => void;
}

export default function StudentGamificationHub({
  onNavigateToGames,
  onNavigateToQuestions
}: StudentGamificationHubProps) {
  // 1. Core State
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('smartedu_gamification_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [activeStudentId, setActiveStudentId] = useState<string>(() => {
    return students[0]?.id || 's1';
  });

  const [pets, setPets] = useState<VirtualPet[]>(() => {
    const saved = localStorage.getItem('smartedu_gamification_pets');
    return saved ? JSON.parse(saved) : INITIAL_PETS;
  });

  const [badges, setBadges] = useState<Badge[]>(() => {
    const saved = localStorage.getItem('smartedu_gamification_badges');
    return saved ? JSON.parse(saved) : INITIAL_BADGES;
  });

  const [quests, setQuests] = useState<Quest[]>(() => {
    const saved = localStorage.getItem('smartedu_gamification_quests');
    return saved ? JSON.parse(saved) : INITIAL_QUESTS;
  });

  const [leaderboards, setLeaderboards] = useState(() => {
    const saved = localStorage.getItem('smartedu_gamification_leaderboards');
    return saved ? JSON.parse(saved) : INITIAL_LEADERBOARDS;
  });

  const [activeSubTab, setActiveSubTab] = useState<'pets' | 'quests' | 'badges' | 'leaderboard' | 'roster'>('pets');

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('smartedu_gamification_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('smartedu_gamification_pets', JSON.stringify(pets));
  }, [pets]);

  useEffect(() => {
    localStorage.setItem('smartedu_gamification_badges', JSON.stringify(badges));
  }, [badges]);

  useEffect(() => {
    localStorage.setItem('smartedu_gamification_quests', JSON.stringify(quests));
  }, [quests]);

  useEffect(() => {
    localStorage.setItem('smartedu_gamification_leaderboards', JSON.stringify(leaderboards));
  }, [leaderboards]);

  // Current active student & active pet
  const currentStudent = students.find(s => s.id === activeStudentId) || students[0];
  const activePetId = currentStudent?.activePetId || 'pet_dog';
  const activePet = pets.find(p => p.id === activePetId) || pets[0];

  // Helper: Update coins for current student
  const handleUpdateCoins = (deltaCoins: number) => {
    setStudents(prev =>
      prev.map(s => {
        if (s.id === currentStudent.id) {
          const updatedCoins = Math.max(0, s.coins + deltaCoins);
          return { ...s, coins: updatedCoins };
        }
        return s;
      })
    );
  };

  // Helper: Add student XP & handle Level-up
  const handleAddStudentXp = (xpDelta: number) => {
    setStudents(prev =>
      prev.map(s => {
        if (s.id === currentStudent.id) {
          let newXp = s.xp + xpDelta;
          let newLevel = s.level;
          let levelUp = false;

          if (newXp >= 100) {
            newLevel += Math.floor(newXp / 100);
            newXp = newXp % 100;
            levelUp = true;
          }

          if (levelUp) {
            sounds.playLevelUp();
            setTimeout(() => {
              alert(`🎉 CHÚC MỪNG! Bé ${s.name} vừa THĂNG CẤP LÊN CẤP ${newLevel}! Nhận thêm 100 xu thưởng! 🌟`);
            }, 100);
            return {
              ...s,
              level: newLevel,
              xp: newXp,
              coins: s.coins + 100
            };
          }

          return { ...s, xp: newXp };
        }
        return s;
      })
    );
  };

  // Helper: Update pet
  const handleUpdatePet = (updatedPet: VirtualPet) => {
    setPets(prev => prev.map(p => (p.id === updatedPet.id ? updatedPet : p)));
  };

  // Helper: Select active companion
  const handleSelectPet = (petId: string) => {
    sounds.playSuccess();
    const pet = pets.find(p => p.id === petId);
    if (!pet) return;

    setStudents(prev =>
      prev.map(s => {
        if (s.id === currentStudent.id) {
          return {
            ...s,
            activePetId: petId,
            petName: pet.name,
            petType: pet.title
          };
        }
        return s;
      })
    );
  };

  // Helper: Unlock pet
  const handleUnlockPet = (petId: string, cost: number) => {
    handleUpdateCoins(-cost);
    setPets(prev =>
      prev.map(p => {
        if (p.id === petId) {
          return { ...p, unlocked: true };
        }
        return p;
      })
    );
    handleSelectPet(petId);
  };

  // Helper: Equip Badge
  const handleEquipBadge = (badgeId: string) => {
    const badge = badges.find(b => b.id === badgeId);
    if (!badge) return;

    setStudents(prev =>
      prev.map(s => {
        if (s.id === currentStudent.id) {
          return {
            ...s,
            equippedBadgeId: badgeId,
            badges: s.badges.includes(badge.name) ? s.badges : [badge.name, ...s.badges]
          };
        }
        return s;
      })
    );

    setBadges(prev =>
      prev.map(b => ({
        ...b,
        isEquipped: b.id === badgeId
      }))
    );
  };

  // Helper: Claim Quest Reward
  const handleClaimQuest = (questId: string) => {
    const quest = quests.find(q => q.id === questId);
    if (!quest || quest.claimed) return;

    handleUpdateCoins(quest.rewardCoins);
    handleAddStudentXp(quest.rewardXp);

    setQuests(prev =>
      prev.map(q => {
        if (q.id === questId) {
          return { ...q, claimed: true };
        }
        return q;
      })
    );
  };

  // Helper: Claim Weekly Mystery Chest
  const handleClaimWeeklyChest = () => {
    handleUpdateCoins(250);
    handleAddStudentXp(200);
  };

  // Teacher manual reward for classroom participation
  const [rewardingId, setRewardingId] = useState<string | null>(null);
  const handleTeacherReward = (studentId: string) => {
    sounds.playCoin();
    setRewardingId(studentId);
    setTimeout(() => setRewardingId(null), 800);

    setStudents(prev =>
      prev.map(s => {
        if (s.id === studentId) {
          let newXp = s.xp + 20;
          let newLevel = s.level;
          if (newXp >= 100) {
            newLevel += 1;
            newXp -= 100;
            sounds.playLevelUp();
          }
          return {
            ...s,
            xp: newXp,
            level: newLevel,
            coins: s.coins + 15
          };
        }
        return s;
      })
    );
  };

  const navItems = [
    { id: 'pets', label: '🐾 Thú Cưng Ảo', icon: '🐶', count: undefined },
    { id: 'quests', label: '🎯 Nhiệm Vụ & Thưởng', icon: '🎁', count: quests.filter(q => q.completed && !q.claimed).length || undefined },
    { id: 'badges', label: '🎖️ Huy Hiệu Thành Tích', icon: '🏆', count: badges.filter(b => b.unlocked).length },
    { id: 'leaderboard', label: '👑 Bảng Xếp Hạng', icon: '🥇', count: undefined },
    { id: 'roster', label: '👦 Quản Lý Lớp & Điểm', icon: '📋', count: students.length }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto space-y-5 select-none animate-fade-in text-left">
      
      {/* Top Student Profile Card & Switcher Header */}
      <div className="bg-white/15 backdrop-blur-2xl p-4 md:p-6 rounded-[36px] border border-white/25 shadow-2xl text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        
        {/* Left: Active Student Avatar, Level & XP */}
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-yellow-300 to-amber-500 p-1 shadow-2xl shrink-0 flex items-center justify-center text-4xl border-2 border-white relative">
            {currentStudent.avatar}
            <span className="absolute -bottom-1 -right-1 bg-indigo-600 text-white font-fredoka font-extrabold text-[10px] w-6 h-6 rounded-full flex items-center justify-center border-2 border-white shadow-md">
              {currentStudent.level}
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-fredoka text-xl md:text-2xl font-extrabold text-white">
                {currentStudent.name}
              </h2>
              <span className="bg-yellow-400/20 text-yellow-300 border border-yellow-300/40 text-[11px] font-fredoka font-bold px-2.5 py-0.5 rounded-full">
                {currentStudent.className || 'Lớp 3A1'}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs text-indigo-100 font-bold mt-1">
              <span className="flex items-center gap-1 text-yellow-300">
                <Star className="w-3.5 h-3.5 fill-yellow-400" />
                <span>{currentStudent.coins} xu vàng</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 text-rose-300">
                <Flame className="w-3.5 h-3.5 fill-rose-400" />
                <span>Chuỗi {currentStudent.streakDays || 7} ngày</span>
              </span>
              <span>•</span>
              <span className="text-emerald-300">
                Pet: {activePet.name} ({activePet.avatar}) Cấp {activePet.level}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Quick Student Switcher Dropdown */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="flex flex-col text-right">
            <span className="text-[10px] text-indigo-200 font-bold">Chuyển góc nhìn học sinh:</span>
            <select
              value={activeStudentId}
              onChange={(e) => {
                sounds.playClick();
                setActiveStudentId(e.target.value);
              }}
              className="p-2.5 bg-indigo-900/80 border border-white/20 rounded-2xl text-xs font-bold text-white outline-none cursor-pointer hover:bg-indigo-800 transition-all"
            >
              {students.map(s => (
                <option key={s.id} value={s.id} className="bg-indigo-950 text-white">
                  {s.avatar} {s.name} (Cấp {s.level} • {s.coins} xu)
                </option>
              ))}
            </select>
          </div>
        </div>

      </div>

      {/* Gamification Sub-Navigation Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {navItems.map(item => {
          const isActive = activeSubTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                sounds.playClick();
                setActiveSubTab(item.id as any);
              }}
              className={`px-5 py-3 rounded-2xl font-fredoka font-extrabold text-xs md:text-sm whitespace-nowrap transition-all flex items-center gap-2 cursor-pointer
                ${isActive 
                  ? 'bg-white text-indigo-700 shadow-xl scale-105 border border-white' 
                  : 'bg-white/10 hover:bg-white/20 text-indigo-100 border border-white/15'
                }
              `}
            >
              <span>{item.label}</span>
              {item.count !== undefined && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${isActive ? 'bg-indigo-100 text-indigo-800' : 'bg-white/20 text-white'}`}>
                  {item.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Dynamic Sub-tab Views */}
      <div>
        {activeSubTab === 'pets' && (
          <VirtualPetSanctuary
            currentStudent={currentStudent}
            pets={pets}
            activePet={activePet}
            onUpdatePet={handleUpdatePet}
            onSelectPet={handleSelectPet}
            onUpdateCoins={handleUpdateCoins}
            onAddStudentXp={handleAddStudentXp}
            onUnlockPet={handleUnlockPet}
          />
        )}

        {activeSubTab === 'quests' && (
          <QuestsMissions
            quests={quests}
            currentStudent={currentStudent}
            onClaimQuest={handleClaimQuest}
            onClaimWeeklyChest={handleClaimWeeklyChest}
            onNavigateToTab={(tab) => {
              if (tab === 'pets') setActiveSubTab('pets');
              else if (tab === 'games' && onNavigateToGames) onNavigateToGames();
            }}
          />
        )}

        {activeSubTab === 'badges' && (
          <BadgeCollection
            badges={badges}
            currentStudent={currentStudent}
            onEquipBadge={handleEquipBadge}
          />
        )}

        {activeSubTab === 'leaderboard' && (
          <MultiLeaderboards
            classLeaderboard={leaderboards.class}
            schoolLeaderboard={leaderboards.school}
            currentStudent={currentStudent}
          />
        )}

        {activeSubTab === 'roster' && (
          <div className="bg-white/15 backdrop-blur-xl rounded-[32px] border border-white/20 p-6 shadow-2xl space-y-5 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-fredoka text-xl font-extrabold text-white flex items-center gap-2">
                  <span>👦 Bảng Điểm & Quản Lý Học Sinh Trong Lớp</span>
                </h3>
                <p className="text-xs text-indigo-100 font-medium mt-1">
                  Giáo viên thưởng sao và xu khích lệ học sinh phát biểu, làm bài tập xuất sắc!
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {students.map(student => {
                const isRewarding = rewardingId === student.id;

                return (
                  <div
                    key={student.id}
                    className="p-5 rounded-2xl bg-white/10 border border-white/15 hover:bg-white/15 transition-all flex flex-col justify-between relative overflow-hidden"
                  >
                    {isRewarding && (
                      <div className="absolute inset-0 bg-yellow-400/20 backdrop-blur-[1px] flex items-center justify-center z-10 pointer-events-none animate-ping">
                        <Star className="w-16 h-16 fill-yellow-400 text-yellow-500 animate-spin" />
                      </div>
                    )}

                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-3xl shadow-inner shrink-0">
                        {student.avatar}
                      </div>

                      <div className="min-w-0">
                        <h4 className="font-fredoka text-sm font-bold text-white truncate">
                          {student.name}
                        </h4>
                        <p className="text-[10px] text-indigo-200 font-medium">
                          🐾 Pet: {student.petName} ({student.petType})
                        </p>
                        <div className="flex items-center gap-2 mt-1 text-[10px] font-fredoka font-bold text-yellow-300">
                          <span>Cấp {student.level}</span>
                          <span>•</span>
                          <span>{student.coins} xu</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                      <span className="text-[10px] text-indigo-200 font-bold">XP: {student.xp}/100</span>

                      <button
                        onClick={() => handleTeacherReward(student.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-400 text-purple-950 font-fredoka font-extrabold text-xs shadow-md hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-1 transition-all"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+15 Xu & Sao 🌟</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

    </div>
  );
}
