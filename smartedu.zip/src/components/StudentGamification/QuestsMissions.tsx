import React, { useState, useEffect } from 'react';
import { Target, Gift, Clock, Sparkles, CheckCircle2, Star, Flame, Trophy, ChevronRight, Zap } from 'lucide-react';
import { Quest, Student } from '../../types';
import { sounds } from '../../lib/audio';

interface QuestsMissionsProps {
  quests: Quest[];
  currentStudent: Student;
  onClaimQuest: (questId: string) => void;
  onClaimWeeklyChest: () => void;
  onNavigateToTab?: (tabId: string) => void;
}

export default function QuestsMissions({
  quests,
  currentStudent,
  onClaimQuest,
  onClaimWeeklyChest,
  onNavigateToTab
}: QuestsMissionsProps) {
  const [activeQuestTab, setActiveQuestTab] = useState<'daily' | 'weekly'>('daily');
  const [claimedChest, setClaimedChest] = useState(false);
  const [showChestModal, setShowChestModal] = useState(false);

  // Countdown timer for daily reset simulation
  const [timeLeft, setTimeLeft] = useState('07:45:30');

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      const diff = endOfDay.getTime() - now.getTime();

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft(
        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      );
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const dailyQuests = quests.filter(q => q.type === 'daily');
  const weeklyQuests = quests.filter(q => q.type === 'weekly');
  const activeList = activeQuestTab === 'daily' ? dailyQuests : weeklyQuests;

  const totalWeeklyCompleted = weeklyQuests.filter(q => q.completed).length;
  const weeklyChestTarget = weeklyQuests.length;
  const canOpenChest = totalWeeklyCompleted >= 3 && !claimedChest;

  const handleClaim = (quest: Quest) => {
    sounds.playCoin();
    onClaimQuest(quest.id);
  };

  const handleOpenChest = () => {
    if (!canOpenChest && !claimedChest) {
      sounds.playError();
      alert(`🔒 Bạn cần hoàn thành ít nhất 3 nhiệm vụ tuần để mở Rương Thần Kỳ! (Hiện tại: ${totalWeeklyCompleted}/${weeklyChestTarget})`);
      return;
    }
    sounds.playGameWin();
    setClaimedChest(true);
    setShowChestModal(true);
    onClaimWeeklyChest();
  };

  return (
    <div className="w-full space-y-6 select-none animate-fade-in text-left">
      
      {/* Top Banner & Weekly Chest Milestone */}
      <div className="bg-gradient-to-r from-purple-900/60 via-indigo-900/60 to-blue-900/60 backdrop-blur-xl p-6 rounded-[32px] border border-white/25 shadow-2xl text-white flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <h2 className="font-fredoka text-xl md:text-2xl font-extrabold text-yellow-300 flex items-center gap-2">
              <Target className="w-6 h-6 text-yellow-300" />
              <span>Bảng Nhiệm Vụ & Phần Thưởng</span>
            </h2>
            <span className="flex items-center gap-1 bg-rose-500/30 text-rose-200 border border-rose-400/40 text-xs font-fredoka font-bold px-3 py-1 rounded-full animate-pulse">
              <Flame className="w-3.5 h-3.5 fill-rose-400 text-rose-500" />
              <span>Chuỗi {currentStudent.streakDays || 5} Ngày</span>
            </span>
          </div>
          <p className="text-xs md:text-sm text-indigo-100 font-medium max-w-xl">
            Hoàn thành nhiệm vụ mỗi ngày để tích lũy xu vàng, thăng cấp thú cưng và mở khóa Rương Kho Báu tuần!
          </p>
        </div>

        {/* Weekly Mega Chest Widget */}
        <div className="w-full lg:w-auto bg-white/10 border border-white/20 p-4 rounded-2xl flex items-center gap-4 shrink-0 shadow-lg">
          <div 
            onClick={handleOpenChest}
            className={`w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-300 flex items-center justify-center text-3xl shadow-xl cursor-pointer transition-all hover:scale-110 active:scale-95
              ${canOpenChest ? 'animate-bounce ring-4 ring-yellow-400/50' : 'opacity-80'}
            `}
          >
            {claimedChest ? '✨' : '🎁'}
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between gap-3 text-xs font-bold text-indigo-100">
              <span>Rương Thần Kỳ Tuần</span>
              <span className="text-yellow-300 font-fredoka">{totalWeeklyCompleted}/{weeklyChestTarget}</span>
            </div>
            <div className="w-36 sm:w-44 bg-black/30 h-2.5 rounded-full overflow-hidden p-[1px]">
              <div 
                className="bg-gradient-to-r from-yellow-300 to-amber-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${(totalWeeklyCompleted / weeklyChestTarget) * 100}%` }}
              ></div>
            </div>
            <span className="text-[10px] text-yellow-300 font-bold block">
              {claimedChest ? '✅ Đã nhận rương tuần' : canOpenChest ? '🎉 Bấm để mở rương ngay!' : 'Cần 3 nhiệm vụ để mở'}
            </span>
          </div>
        </div>

      </div>

      {/* Tabs & Reset Clock Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        
        {/* Tab Pills */}
        <div className="flex items-center gap-2 bg-white/10 backdrop-blur-xl p-1.5 rounded-2xl border border-white/15">
          <button
            onClick={() => {
              sounds.playClick();
              setActiveQuestTab('daily');
            }}
            className={`px-5 py-2.5 rounded-xl font-fredoka font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer
              ${activeQuestTab === 'daily' 
                ? 'bg-yellow-400 text-purple-950 shadow-md scale-105 border border-white' 
                : 'text-indigo-100 hover:bg-white/10 hover:text-white'
              }
            `}
          >
            <span>📅 Nhiệm Vụ Hàng Ngày</span>
            <span className="bg-purple-950/20 text-purple-950 px-1.5 py-0.2 rounded-full text-[10px]">
              {dailyQuests.filter(q => q.completed && !q.claimed).length > 0 && '🎁'}
            </span>
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              setActiveQuestTab('weekly');
            }}
            className={`px-5 py-2.5 rounded-xl font-fredoka font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer
              ${activeQuestTab === 'weekly' 
                ? 'bg-yellow-400 text-purple-950 shadow-md scale-105 border border-white' 
                : 'text-indigo-100 hover:bg-white/10 hover:text-white'
              }
            `}
          >
            <span>🗓️ Nhiệm Vụ Tuần</span>
          </button>
        </div>

        {/* Reset Clock */}
        <div className="flex items-center gap-2 bg-black/20 text-indigo-200 px-4 py-2 rounded-2xl text-xs font-bold border border-white/10">
          <Clock className="w-4 h-4 text-yellow-300 animate-spin" style={{ animationDuration: '10s' }} />
          <span>Làm mới sau: <strong className="text-white font-fredoka tracking-wider">{timeLeft}</strong></span>
        </div>

      </div>

      {/* Quest Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {activeList.map(quest => {
          const progressPercent = Math.min(100, Math.round((quest.progress / quest.target) * 100));

          return (
            <div
              key={quest.id}
              className={`rounded-[28px] p-5 border backdrop-blur-xl shadow-xl flex flex-col justify-between transition-all duration-300
                ${quest.claimed 
                  ? 'bg-black/20 border-white/10 opacity-70' 
                  : quest.completed 
                    ? 'bg-gradient-to-r from-emerald-900/30 to-teal-900/30 border-emerald-400/50 shadow-emerald-500/10' 
                    : 'bg-white/15 border-white/20 hover:bg-white/20'
                }
              `}
            >
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-2xl shadow-inner border border-white/15 shrink-0">
                  {quest.icon}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-fredoka text-sm font-extrabold text-white truncate">
                      {quest.title}
                    </h4>
                    <span className="text-[10px] font-fredoka font-bold text-yellow-300 bg-yellow-400/20 px-2 py-0.5 rounded-full border border-yellow-300/30 shrink-0">
                      +{quest.rewardCoins} xu
                    </span>
                  </div>

                  <p className="text-[11px] text-indigo-200 font-medium line-clamp-2 mt-1 leading-relaxed">
                    {quest.description}
                  </p>
                </div>
              </div>

              {/* Progress and Claim CTA */}
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between gap-4">
                <div className="flex-1 space-y-1">
                  <div className="flex justify-between text-[10px] font-bold text-indigo-200">
                    <span>Tiến trình: {quest.progress}/{quest.target}</span>
                    <span>{progressPercent}%</span>
                  </div>
                  <div className="w-full bg-black/30 h-2 rounded-full overflow-hidden p-[0.5px]">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${quest.completed ? 'bg-emerald-400' : 'bg-yellow-400'}`}
                      style={{ width: `${progressPercent}%` }}
                    ></div>
                  </div>
                </div>

                {/* Claim Button */}
                <div>
                  {quest.claimed ? (
                    <span className="text-xs text-emerald-300 font-fredoka font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Đã nhận</span>
                    </span>
                  ) : quest.completed ? (
                    <button
                      onClick={() => handleClaim(quest)}
                      className="px-4 py-2 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-400 text-purple-950 font-fredoka font-extrabold text-xs shadow-lg hover:scale-105 active:scale-95 cursor-pointer animate-bounce flex items-center gap-1.5 transition-all"
                    >
                      <Gift className="w-3.5 h-3.5" />
                      <span>Nhận Thưởng 🎁</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playClick();
                        if (quest.category === 'pet' && onNavigateToTab) {
                          onNavigateToTab('pets');
                        } else if (quest.category === 'quiz' && onNavigateToTab) {
                          onNavigateToTab('games');
                        }
                      }}
                      className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-fredoka font-bold text-[11px] cursor-pointer flex items-center gap-1 transition-all"
                    >
                      <span>Làm ngay</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Mystery Chest Reward Modal */}
      {showChestModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="w-full max-w-md bg-gradient-to-b from-[#2F1E6B] to-[#1C1145] rounded-[36px] border-2 border-yellow-300/60 shadow-2xl p-6 md:p-8 text-white text-center relative overflow-hidden">
            
            {/* Sparkles effect */}
            <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-tr from-yellow-300 to-amber-500 flex items-center justify-center text-6xl shadow-2xl animate-bounce mb-4">
              🎁
            </div>

            <h3 className="font-fredoka text-2xl font-extrabold text-yellow-300 mb-2">
              CHÚC MỪNG BÉ YÊU!
            </h3>
            <p className="text-xs text-indigo-100 leading-relaxed font-medium mb-5">
              Bạn đã mở thành công Rương Kho Báu Tuần và nhận được những phần quà siêu giá trị:
            </p>

            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="bg-yellow-400/20 border border-yellow-300/40 p-3 rounded-2xl flex flex-col items-center">
                <span className="text-2xl mb-1">💰</span>
                <span className="font-fredoka font-bold text-sm text-yellow-300">+250 Xu Vàng</span>
              </div>
              <div className="bg-purple-400/20 border border-purple-300/40 p-3 rounded-2xl flex flex-col items-center">
                <span className="text-2xl mb-1">👑</span>
                <span className="font-fredoka font-bold text-sm text-purple-200">+200 XP Thăng Cấp</span>
              </div>
            </div>

            <button
              onClick={() => {
                sounds.playCoin();
                setShowChestModal(false);
              }}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-400 text-purple-950 font-fredoka font-extrabold text-sm shadow-xl hover:scale-105 cursor-pointer transition-all"
            >
              Tuyệt Vời! Thu Thập Quà Ngay ⭐
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
