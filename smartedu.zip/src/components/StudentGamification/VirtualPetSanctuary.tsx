import React, { useState } from 'react';
import { 
  Sparkles, Heart, Zap, Award, ShoppingBag, 
  Smile, Shield, ChevronRight, Lock, Check, Gift,
  Volume2, RefreshCw, Star
} from 'lucide-react';
import { VirtualPet, PetFoodItem, PetAccessoryItem, Student } from '../../types';
import { PET_FOODS, PET_ACCESSORIES } from '../../data/gamificationData';
import { sounds } from '../../lib/audio';
import PetMiniQuizModal from './PetMiniQuizModal';

interface VirtualPetSanctuaryProps {
  currentStudent: Student;
  pets: VirtualPet[];
  activePet: VirtualPet;
  onUpdatePet: (updatedPet: VirtualPet) => void;
  onSelectPet: (petId: string) => void;
  onUpdateCoins: (deltaCoins: number) => void;
  onAddStudentXp: (xpDelta: number) => void;
  onUnlockPet: (petId: string, cost: number) => void;
}

export default function VirtualPetSanctuary({
  currentStudent,
  pets,
  activePet,
  onUpdatePet,
  onSelectPet,
  onUpdateCoins,
  onAddStudentXp,
  onUnlockPet
}: VirtualPetSanctuaryProps) {
  const [showFoodDrawer, setShowFoodDrawer] = useState(false);
  const [showAccessoryDrawer, setShowAccessoryDrawer] = useState(false);
  const [showAdoptionModal, setShowAdoptionModal] = useState(false);
  const [showQuizModal, setShowQuizModal] = useState(false);

  // Visual effects trigger
  const [actionEffect, setActionEffect] = useState<{
    type: 'hearts' | 'bubbles' | 'stars' | 'food' | 'sleep' | 'levelUp';
    message: string;
  } | null>(null);

  const triggerEffect = (type: 'hearts' | 'bubbles' | 'stars' | 'food' | 'sleep' | 'levelUp', message: string) => {
    setActionEffect({ type, message });
    setTimeout(() => setActionEffect(null), 1500);
  };

  // 1. Action: Pet / Cuddle (Vuốt ve)
  const handlePetCuddle = () => {
    sounds.playCoin();
    const newHappiness = Math.min(100, activePet.happiness + 12);
    const newFriendship = Math.min(100, activePet.friendship + 8);
    const newXp = activePet.xp + 10;
    
    let updated = { ...activePet, happiness: newHappiness, friendship: newFriendship, xp: newXp };
    updated = checkPetLevelUp(updated);
    onUpdatePet(updated);

    triggerEffect('hearts', '💖 Thú cưng rất thích được bạn vuốt ve!');
  };

  // 2. Action: Feed (Cho ăn)
  const handleFeedItem = (food: PetFoodItem) => {
    if (currentStudent.coins < food.cost) {
      sounds.playError();
      alert(`⚠️ Bé chưa đủ xu! Cần ${food.cost} xu (Bé đang có ${currentStudent.coins} xu). Hãy làm thêm nhiệm vụ nhé!`);
      return;
    }

    sounds.playCoin();
    onUpdateCoins(-food.cost);

    const newHunger = Math.min(100, activePet.hunger + food.hungerBonus);
    const newHappiness = Math.min(100, activePet.happiness + food.happinessBonus);
    const newEnergy = Math.min(100, activePet.energy + food.energyBonus);
    const newXp = activePet.xp + 15;

    let updated = {
      ...activePet,
      hunger: newHunger,
      happiness: newHappiness,
      energy: newEnergy,
      xp: newXp
    };
    updated = checkPetLevelUp(updated);
    onUpdatePet(updated);

    triggerEffect('food', `🍎 Đã cho ${activePet.name} ăn ${food.name}! +${food.hungerBonus}% No`);
  };

  // 3. Action: Clean / Bathe (Tắm rửa)
  const handleBathe = () => {
    sounds.playSuccess();
    const newCleanliness = 100;
    const newHappiness = Math.min(100, activePet.happiness + 15);
    const newXp = activePet.xp + 12;

    let updated = { ...activePet, cleanliness: newCleanliness, happiness: newHappiness, xp: newXp };
    updated = checkPetLevelUp(updated);
    onUpdatePet(updated);

    triggerEffect('bubbles', '🛁 Tắm rửa mát rượi, thơm tho sạch bóng 100%!');
  };

  // 4. Action: Play (Chơi đùa)
  const handlePlayGame = () => {
    if (activePet.energy < 15) {
      sounds.playError();
      alert(`😴 ${activePet.name} đang mệt quá (Năng lượng < 15%). Hãy cho pet nghỉ ngơi hoặc ăn thêm nhé!`);
      return;
    }

    sounds.playGameWin();
    const newEnergy = Math.max(0, activePet.energy - 15);
    const newHappiness = Math.min(100, activePet.happiness + 20);
    const newFriendship = Math.min(100, activePet.friendship + 10);
    const newXp = activePet.xp + 20;

    let updated = { ...activePet, energy: newEnergy, happiness: newHappiness, friendship: newFriendship, xp: newXp };
    updated = checkPetLevelUp(updated);
    onUpdatePet(updated);

    triggerEffect('stars', `⚽ Chơi đùa vui vẻ cùng ${activePet.name}! +20% Vui vẻ`);
  };

  // 5. Action: Rest / Sleep (Cho đi ngủ)
  const handleSleep = () => {
    sounds.playSuccess();
    const newEnergy = 100;
    const updated = { ...activePet, energy: newEnergy };
    onUpdatePet(updated);
    triggerEffect('sleep', `💤 ${activePet.name} đã ngủ ngon và nạp đầy 100% Năng lượng!`);
  };

  // Check pet level up & evolution
  const checkPetLevelUp = (pet: VirtualPet): VirtualPet => {
    if (pet.xp >= pet.maxXp) {
      const newLevel = pet.level + 1;
      const leftoverXp = pet.xp - pet.maxXp;
      const newMaxXp = Math.round(pet.maxXp * 1.3);

      // Determine evolution stage
      let stage = pet.stage;
      if (newLevel >= 6) stage = 'legendary';
      else if (newLevel >= 4) stage = 'teen';
      else if (newLevel >= 2) stage = 'baby';

      sounds.playLevelUp();
      setTimeout(() => {
        alert(`🌟 THĂNG CẤP THÚ CƯNG! ${pet.name} vừa đạt CẤP ${newLevel} (${stage.toUpperCase()})! Bạn nhận thêm 50 xu thưởng! 🎁`);
      }, 200);

      onUpdateCoins(50);
      onAddStudentXp(30);

      return {
        ...pet,
        level: newLevel,
        xp: leftoverXp,
        maxXp: newMaxXp,
        stage
      };
    }
    return pet;
  };

  // Equip / Buy accessory
  const handleToggleAccessory = (acc: PetAccessoryItem) => {
    if (!acc.owned) {
      if (currentStudent.coins < acc.cost) {
        sounds.playError();
        alert(`⚠️ Bạn cần ${acc.cost} xu để mở khóa ${acc.name}!`);
        return;
      }
      // Buy
      sounds.playSuccess();
      onUpdateCoins(-acc.cost);
      acc.owned = true;
    }

    // Toggle equipment
    const isEquipped = activePet.accessories.includes(acc.id);
    let newAccs = [...activePet.accessories];
    if (isEquipped) {
      newAccs = newAccs.filter(id => id !== acc.id);
      sounds.playClick();
    } else {
      newAccs.push(acc.id);
      sounds.playCoin();
    }

    onUpdatePet({ ...activePet, accessories: newAccs });
  };

  const getStageTitle = (stage: string) => {
    switch (stage) {
      case 'egg': return 'Trứng Thần Kỳ 🥚';
      case 'baby': return 'Thú Con Đáng Yêu 🍼';
      case 'teen': return 'Thiếu Niên Năng Động ⚡';
      case 'legendary': return 'Thần Thú Giáp Vàng 👑';
      default: return 'Trưởng Thành';
    }
  };

  return (
    <div className="w-full space-y-6 select-none animate-fade-in text-left">
      
      {/* Top Banner: Active Student & Pet Sanctuary Info */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white/10 backdrop-blur-xl p-5 md:p-6 rounded-[32px] border border-white/20 shadow-xl text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-300 p-1 shadow-lg shrink-0 flex items-center justify-center text-3xl animate-bounce">
            {activePet.avatar}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-fredoka text-xl md:text-2xl font-extrabold text-white">
                {activePet.name} - {activePet.title}
              </span>
              <span className="px-3 py-1 bg-yellow-400/20 text-yellow-300 border border-yellow-300/40 rounded-full font-fredoka font-bold text-xs">
                Cấp {activePet.level}
              </span>
            </div>
            <p className="text-xs md:text-sm text-indigo-100 font-medium mt-1">
              Đồng hành cùng bé <span className="font-bold text-yellow-300">{currentStudent.name}</span> • Giai đoạn: <span className="text-emerald-300 font-bold">{getStageTitle(activePet.stage)}</span>
            </p>
          </div>
        </div>

        {/* Action Buttons: Adopt new pets & Switch companions */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            onClick={() => {
              sounds.playClick();
              setShowAdoptionModal(true);
            }}
            className="flex-1 md:flex-none px-4 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/20 text-indigo-100 font-fredoka font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all hover:scale-105"
          >
            <span>🐾 Đổi Thú Cưng ({pets.length})</span>
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              setShowAccessoryDrawer(true);
            }}
            className="flex-1 md:flex-none px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-fredoka font-extrabold text-xs shadow-md flex items-center justify-center gap-1.5 cursor-pointer transition-all hover:scale-105"
          >
            <ShoppingBag className="w-4 h-4 text-yellow-300" />
            <span>Tủ Đồ Phụ Kiện</span>
          </button>
        </div>
      </div>

      {/* Main Pet Playroom Interactive Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: The 3D Pet Play Arena */}
        <div className="lg:col-span-2 bg-gradient-to-b from-indigo-900/60 via-purple-900/40 to-indigo-950/80 backdrop-blur-2xl rounded-[36px] border border-white/25 p-6 md:p-8 shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[460px] text-white">
          
          {/* Animated Sky Backdrop with Floating Clouds & Sparkles */}
          <div className="absolute top-6 left-8 text-4xl opacity-30 animate-float pointer-events-none">☁️</div>
          <div className="absolute top-12 right-12 text-3xl opacity-20 animate-float-slow pointer-events-none">✨</div>
          <div className="absolute bottom-24 left-16 text-3xl opacity-25 animate-pulse-star pointer-events-none">⭐</div>
          <div className="absolute top-20 left-1/2 text-2xl opacity-15 animate-float pointer-events-none">🌈</div>

          {/* Top Stage Bar: Mood & Pet Level Progress */}
          <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/15">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-100">
              <Smile className="w-4 h-4 text-yellow-300" />
              <span>Tâm trạng: <span className="text-white font-fredoka">{activePet.currentMood}</span></span>
            </div>

            {/* Pet XP Bar */}
            <div className="w-full sm:w-48 space-y-1">
              <div className="flex justify-between text-[10px] text-indigo-200 font-bold">
                <span>XP Cấp {activePet.level}</span>
                <span>{activePet.xp}/{activePet.maxXp} XP</span>
              </div>
              <div className="w-full bg-black/30 h-2.5 rounded-full overflow-hidden border border-white/10 p-[1px]">
                <div 
                  className="bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (activePet.xp / activePet.maxXp) * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Central Pet Character View with Speech Bubble */}
          <div className="relative z-10 my-auto py-6 flex flex-col items-center justify-center">
            
            {/* Action Popup Notification */}
            {actionEffect && (
              <div className="absolute -top-6 bg-yellow-400 text-purple-950 px-5 py-2 rounded-2xl font-fredoka font-extrabold text-sm shadow-2xl border-2 border-white animate-bounce z-20 flex items-center gap-2">
                <Sparkles className="w-4 h-4 fill-amber-500" />
                <span>{actionEffect.message}</span>
              </div>
            )}

            {/* Pet Dialogue Bubble */}
            <div className="mb-4 bg-white text-indigo-950 px-5 py-3 rounded-2xl rounded-bl-none shadow-xl max-w-sm text-center relative border-2 border-yellow-300 animate-float-slow">
              <p className="font-fredoka font-bold text-xs md:text-sm">
                "{activePet.quote}"
              </p>
              <div className="absolute -bottom-2 left-6 w-4 h-4 bg-white border-b-2 border-r-2 border-yellow-300 transform rotate-45"></div>
            </div>

            {/* Interactive Pet Character Container (Click to cuddle) */}
            <div 
              onClick={handlePetCuddle}
              className="relative cursor-pointer group select-none transition-all duration-300 hover:scale-110 active:scale-95"
              title="Nhấn vào để vuốt ve và yêu thương bé nhé!"
            >
              {/* Floor Shadow Pod */}
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-32 md:w-40 h-8 bg-black/40 rounded-full blur-sm"></div>

              {/* Character Avatar Bubble */}
              <div className="w-36 h-36 md:w-44 md:h-44 rounded-full bg-gradient-to-tr from-white/25 to-white/5 backdrop-blur-md border-4 border-white/40 flex items-center justify-center text-7xl md:text-8xl shadow-2xl relative">
                {activePet.avatar}

                {/* Equipped Accessories Render */}
                {activePet.accessories.includes('hat_detective') && (
                  <span className="absolute -top-3 left-6 text-4xl animate-bounce">🎩</span>
                )}
                {activePet.accessories.includes('crown_gold') && (
                  <span className="absolute -top-4 left-1/2 -translate-x-1/2 text-4xl animate-pulse">👑</span>
                )}
                {activePet.accessories.includes('glasses_smart') && (
                  <span className="absolute top-10 left-1/2 -translate-x-1/2 text-3xl">👓</span>
                )}
                {activePet.accessories.includes('wings_magic') && (
                  <span className="absolute -left-6 top-10 text-4xl animate-pulse">🧚</span>
                )}
                {activePet.accessories.includes('bell_lucky') && (
                  <span className="absolute bottom-2 right-4 text-3xl">🔔</span>
                )}
              </div>

              {/* Click Heart Hover Hint */}
              <div className="absolute -top-2 right-2 bg-pink-500 text-white font-fredoka font-bold text-[10px] px-2.5 py-1 rounded-full shadow-lg border border-white flex items-center gap-1 group-hover:scale-110 transition-all">
                <Heart className="w-3 h-3 fill-white" />
                <span>Vuốt ve</span>
              </div>
            </div>

            <p className="text-[11px] text-indigo-200 font-bold mt-4 tracking-wide">
              👆 Nhấp chuột vào thú cưng để vuốt ve & tăng điểm Thân Mật
            </p>
          </div>

          {/* Bottom Interactive Action Toolbar */}
          <div className="relative z-10 grid grid-cols-3 sm:grid-cols-6 gap-2 pt-4 border-t border-white/15">
            
            {/* 1. Cho ăn */}
            <button
              onClick={() => {
                sounds.playClick();
                setShowFoodDrawer(true);
              }}
              className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span className="text-2xl mb-1">🍎</span>
              <span className="font-fredoka font-bold text-[11px] text-white">Cho Ăn</span>
            </button>

            {/* 2. Tắm rửa */}
            <button
              onClick={handleBathe}
              className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span className="text-2xl mb-1">🛁</span>
              <span className="font-fredoka font-bold text-[11px] text-white">Tắm Rửa</span>
            </button>

            {/* 3. Vuốt ve */}
            <button
              onClick={handlePetCuddle}
              className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span className="text-2xl mb-1">💖</span>
              <span className="font-fredoka font-bold text-[11px] text-white">Vuốt Ve</span>
            </button>

            {/* 4. Đố vui */}
            <button
              onClick={() => {
                sounds.playClick();
                setShowQuizModal(true);
              }}
              className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-gradient-to-b from-yellow-400/30 to-amber-500/30 hover:from-yellow-400/40 hover:to-amber-500/40 border border-yellow-300/40 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span className="text-2xl mb-1">🧠</span>
              <span className="font-fredoka font-bold text-[11px] text-yellow-300">Đố Vui</span>
            </button>

            {/* 5. Chơi đùa */}
            <button
              onClick={handlePlayGame}
              className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span className="text-2xl mb-1">⚽</span>
              <span className="font-fredoka font-bold text-[11px] text-white">Chơi Đùa</span>
            </button>

            {/* 6. Đi ngủ */}
            <button
              onClick={handleSleep}
              className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span className="text-2xl mb-1">😴</span>
              <span className="font-fredoka font-bold text-[11px] text-white">Nghỉ Ngơi</span>
            </button>

          </div>
        </div>

        {/* Right 1 Col: Pet Vitals Dashboard & Quick Tasks */}
        <div className="space-y-5">
          
          {/* Pet Vitals Meters */}
          <div className="bg-white/15 backdrop-blur-xl rounded-[32px] border border-white/20 p-5 md:p-6 shadow-2xl space-y-4 text-white">
            <h3 className="font-fredoka text-lg font-extrabold text-white flex items-center justify-between">
              <span>📊 Chỉ Số Sức Khỏe Pet</span>
              <span className="text-xs text-yellow-300 font-sans font-bold">{currentStudent.coins} xu</span>
            </h3>

            <div className="space-y-3 text-xs font-bold text-indigo-100">
              
              {/* Hunger */}
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="flex items-center gap-1.5">🍗 No bụng:</span>
                  <span className="text-white font-fredoka">{activePet.hunger}%</span>
                </div>
                <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden p-[1px]">
                  <div 
                    className="bg-gradient-to-r from-orange-400 to-amber-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${activePet.hunger}%` }}
                  ></div>
                </div>
              </div>

              {/* Happiness */}
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="flex items-center gap-1.5">💖 Vui vẻ & Hạnh phúc:</span>
                  <span className="text-white font-fredoka">{activePet.happiness}%</span>
                </div>
                <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden p-[1px]">
                  <div 
                    className="bg-gradient-to-r from-pink-400 to-rose-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${activePet.happiness}%` }}
                  ></div>
                </div>
              </div>

              {/* Energy */}
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="flex items-center gap-1.5">⚡ Năng lượng học tập:</span>
                  <span className="text-white font-fredoka">{activePet.energy}%</span>
                </div>
                <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden p-[1px]">
                  <div 
                    className="bg-gradient-to-r from-emerald-400 to-teal-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${activePet.energy}%` }}
                  ></div>
                </div>
              </div>

              {/* Cleanliness */}
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="flex items-center gap-1.5">🧼 Sạch sẽ thơm tho:</span>
                  <span className="text-white font-fredoka">{activePet.cleanliness}%</span>
                </div>
                <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden p-[1px]">
                  <div 
                    className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${activePet.cleanliness}%` }}
                  ></div>
                </div>
              </div>

              {/* Friendship */}
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="flex items-center gap-1.5">❤️ Độ thân mật:</span>
                  <span className="text-white font-fredoka">{activePet.friendship}%</span>
                </div>
                <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden p-[1px]">
                  <div 
                    className="bg-gradient-to-r from-purple-400 to-indigo-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${activePet.friendship}%` }}
                  ></div>
                </div>
              </div>

            </div>

            <div className="p-3 bg-white/10 rounded-2xl border border-white/15 text-[11px] text-indigo-100 flex items-start gap-2">
              <Gift className="w-4 h-4 text-yellow-300 shrink-0 mt-0.5" />
              <span>
                <strong className="text-white">Mẹo nuôi thú:</strong> Thú cưng vui vẻ trên 90% sẽ cộng thêm <strong className="text-yellow-300">+20% XP thưởng</strong> cho bạn mỗi khi hoàn thành bài tập!
              </span>
            </div>
          </div>

          {/* Quick Pet Food Stock */}
          <div className="bg-white/15 backdrop-blur-xl rounded-[32px] border border-white/20 p-5 shadow-2xl space-y-3 text-white">
            <div className="flex items-center justify-between">
              <h4 className="font-fredoka text-sm font-extrabold text-white">
                🍎 Thực Đơn Yêu Thích
              </h4>
              <button
                onClick={() => {
                  sounds.playClick();
                  setShowFoodDrawer(true);
                }}
                className="text-xs font-bold text-yellow-300 hover:underline cursor-pointer"
              >
                Xem tất cả ➔
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {PET_FOODS.slice(0, 3).map(food => (
                <button
                  key={food.id}
                  onClick={() => handleFeedItem(food)}
                  className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 flex flex-col items-center text-center cursor-pointer transition-all hover:scale-105 active:scale-95"
                >
                  <span className="text-2xl mb-1">{food.icon}</span>
                  <span className="font-fredoka text-[10px] text-white truncate w-full">{food.name}</span>
                  <span className="text-[9px] text-yellow-300 font-bold mt-0.5">{food.cost} xu</span>
                </button>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* 1. Food Shop Modal */}
      {showFoodDrawer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="w-full max-w-lg bg-[#22184F] rounded-[36px] border-2 border-white/25 shadow-2xl p-6 text-white relative">
            <button
              onClick={() => {
                sounds.playClick();
                setShowFoodDrawer(false);
              }}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-sm font-bold cursor-pointer"
            >
              ✕
            </button>

            <h3 className="font-fredoka text-xl font-extrabold text-yellow-300 flex items-center gap-2 mb-1">
              🍎 Cửa Hàng Thức Ăn Dinh Dưỡng
            </h3>
            <p className="text-xs text-indigo-200 mb-4">
              Số dư hiện tại của bé: <span className="text-yellow-300 font-bold">{currentStudent.coins} xu</span>
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[380px] overflow-y-auto pr-1">
              {PET_FOODS.map(food => (
                <div 
                  key={food.id}
                  className="bg-white/10 border border-white/15 rounded-2xl p-3.5 flex items-center justify-between gap-3 hover:bg-white/15 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-2xl shadow-inner shrink-0">
                      {food.icon}
                    </div>
                    <div className="min-w-0">
                      <h5 className="font-fredoka text-xs font-bold text-white truncate">{food.name}</h5>
                      <p className="text-[10px] text-indigo-200 line-clamp-1">{food.description}</p>
                      <div className="flex gap-1.5 text-[9px] text-emerald-300 font-bold mt-1">
                        <span>+{food.hungerBonus}% No</span>
                        <span>+{food.happinessBonus}% Vui</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleFeedItem(food)}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-yellow-300 to-amber-400 text-purple-950 font-fredoka font-extrabold text-xs shadow-md shrink-0 hover:scale-105 active:scale-95 cursor-pointer transition-all"
                  >
                    {food.cost} xu
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. Accessories & Dressing Room Modal */}
      {showAccessoryDrawer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="w-full max-w-lg bg-[#22184F] rounded-[36px] border-2 border-white/25 shadow-2xl p-6 text-white relative">
            <button
              onClick={() => {
                sounds.playClick();
                setShowAccessoryDrawer(false);
              }}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-sm font-bold cursor-pointer"
            >
              ✕
            </button>

            <h3 className="font-fredoka text-xl font-extrabold text-purple-300 flex items-center gap-2 mb-1">
              👗 Tủ Đồ & Phụ Kiện Thời Trang
            </h3>
            <p className="text-xs text-indigo-200 mb-4">
              Làm đẹp cho <span className="text-yellow-300 font-bold">{activePet.name}</span> bằng các phụ kiện phong cách!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[380px] overflow-y-auto pr-1">
              {PET_ACCESSORIES.map(acc => {
                const isEquipped = activePet.accessories.includes(acc.id);

                return (
                  <div 
                    key={acc.id}
                    className={`border rounded-2xl p-3.5 flex items-center justify-between gap-3 transition-all
                      ${isEquipped ? 'bg-purple-600/30 border-purple-400 ring-2 ring-purple-400/40' : 'bg-white/10 border-white/15'}
                    `}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-2xl shadow-inner shrink-0">
                        {acc.icon}
                      </div>
                      <div className="min-w-0">
                        <h5 className="font-fredoka text-xs font-bold text-white truncate">{acc.name}</h5>
                        <p className="text-[10px] text-indigo-200 line-clamp-1">{acc.description}</p>
                        <span className="text-[9px] text-yellow-300 font-bold mt-1 block">
                          {acc.owned ? '✅ Đã sở hữu' : `${acc.cost} xu`}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleToggleAccessory(acc)}
                      className={`px-3 py-2 rounded-xl font-fredoka font-extrabold text-xs shadow-md shrink-0 hover:scale-105 active:scale-95 cursor-pointer transition-all
                        ${isEquipped 
                          ? 'bg-rose-500 text-white' 
                          : acc.owned 
                            ? 'bg-emerald-500 text-white' 
                            : 'bg-yellow-400 text-purple-950'
                        }
                      `}
                    >
                      {isEquipped ? 'Tháo ra' : acc.owned ? 'Đeo vào' : `Mua`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 3. Pet Adoption & Switch Modal */}
      {showAdoptionModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="w-full max-w-2xl bg-[#22184F] rounded-[36px] border-2 border-white/25 shadow-2xl p-6 md:p-8 text-white relative">
            <button
              onClick={() => {
                sounds.playClick();
                setShowAdoptionModal(false);
              }}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-sm font-bold cursor-pointer"
            >
              ✕
            </button>

            <h3 className="font-fredoka text-xl md:text-2xl font-extrabold text-emerald-300 flex items-center gap-2 mb-1">
              🐾 Nông Trại Nhận Nuôi Thú Cưng
            </h3>
            <p className="text-xs text-indigo-200 mb-5">
              Chọn người bạn đồng hành trung thành trên con đường chinh phục tri thức!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 max-h-[420px] overflow-y-auto pr-1">
              {pets.map(pet => {
                const isActive = pet.id === activePet.id;

                return (
                  <div 
                    key={pet.id}
                    className={`p-4 rounded-2xl border flex flex-col justify-between text-center relative transition-all
                      ${isActive ? 'bg-emerald-500/25 border-emerald-400 ring-2 ring-emerald-400/50 shadow-xl' : 'bg-white/10 border-white/15 hover:bg-white/15'}
                    `}
                  >
                    <div>
                      <div className="w-16 h-16 mx-auto rounded-2xl bg-white/10 flex items-center justify-center text-4xl shadow-inner mb-2">
                        {pet.avatar}
                      </div>
                      <h4 className="font-fredoka text-sm font-bold text-white">{pet.name}</h4>
                      <p className="text-[10px] text-indigo-200 font-medium">{pet.title}</p>
                      <div className="mt-2 flex justify-center gap-1.5 text-[9px] font-fredoka font-bold">
                        <span className="bg-yellow-400/20 text-yellow-300 px-2 py-0.5 rounded-full">Cấp {pet.level}</span>
                        <span className="bg-indigo-400/20 text-indigo-200 px-2 py-0.5 rounded-full">{getStageTitle(pet.stage)}</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-2 border-t border-white/10">
                      {pet.unlocked ? (
                        <button
                          onClick={() => {
                            sounds.playClick();
                            onSelectPet(pet.id);
                            setShowAdoptionModal(false);
                          }}
                          disabled={isActive}
                          className={`w-full py-2 rounded-xl font-fredoka font-extrabold text-xs transition-all cursor-pointer
                            ${isActive ? 'bg-emerald-500 text-white opacity-80 cursor-default' : 'bg-white/20 hover:bg-white/30 text-white hover:scale-105'}
                          `}
                        >
                          {isActive ? '🌟 Đang chọn' : 'Đồng hành'}
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            if (currentStudent.coins < pet.unlockCost) {
                              sounds.playError();
                              alert(`⚠️ Bé cần ${pet.unlockCost} xu để nhận nuôi ${pet.name}!`);
                              return;
                            }
                            sounds.playSuccess();
                            onUnlockPet(pet.id, pet.unlockCost);
                          }}
                          className="w-full py-2 rounded-xl bg-gradient-to-r from-yellow-300 to-amber-400 text-purple-950 font-fredoka font-extrabold text-xs shadow-md hover:scale-105 cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Lock className="w-3 h-3" />
                          <span>Mở khóa ({pet.unlockCost} xu)</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 4. Pet Mini Quiz Modal */}
      {showQuizModal && (
        <PetMiniQuizModal
          petName={activePet.name}
          petAvatar={activePet.avatar}
          onClose={() => setShowQuizModal(false)}
          onSuccess={(coins, petXp) => {
            onUpdateCoins(coins);
            let updated = { ...activePet, xp: activePet.xp + petXp, happiness: Math.min(100, activePet.happiness + 20) };
            updated = checkPetLevelUp(updated);
            onUpdatePet(updated);
            triggerEffect('stars', `🎉 Đố vui thành công! Nhận +${coins} xu và +${petXp} Pet XP!`);
          }}
        />
      )}

    </div>
  );
}
