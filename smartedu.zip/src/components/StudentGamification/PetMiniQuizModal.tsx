import React, { useState } from 'react';
import { Sparkles, CheckCircle, HelpCircle } from 'lucide-react';
import { sounds } from '../../lib/audio';
import { PET_TRIVIA_QUESTIONS } from '../../data/gamificationData';

interface PetMiniQuizModalProps {
  petName: string;
  petAvatar: string;
  onClose: () => void;
  onSuccess: (rewardCoins: number, rewardPetXp: number) => void;
}

export default function PetMiniQuizModal({ petName, petAvatar, onClose, onSuccess }: PetMiniQuizModalProps) {
  const [currentIdx, setCurrentIdx] = useState(() => Math.floor(Math.random() * PET_TRIVIA_QUESTIONS.length));
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const currentQ = PET_TRIVIA_QUESTIONS[currentIdx];

  const handleSelect = (opt: string) => {
    if (isAnswered) return;
    sounds.playClick();
    setSelectedOption(opt);
    setIsAnswered(true);

    const correct = opt === currentQ.answer;
    setIsCorrect(correct);

    if (correct) {
      sounds.playSuccess();
    } else {
      sounds.playError();
    }
  };

  const handleClaim = () => {
    sounds.playCoin();
    onSuccess(30, 25);
    onClose();
  };

  const handleRetry = () => {
    sounds.playClick();
    const nextIdx = (currentIdx + 1) % PET_TRIVIA_QUESTIONS.length;
    setCurrentIdx(nextIdx);
    setSelectedOption(null);
    setIsAnswered(false);
    setIsCorrect(false);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fade-in select-none">
      <div className="w-full max-w-lg bg-gradient-to-b from-[#251A5A] to-[#171038] rounded-[36px] border-2 border-yellow-300/40 shadow-2xl p-6 md:p-8 text-white relative overflow-hidden">
        
        {/* Floating background lights */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-yellow-400/10 rounded-full blur-2xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-36 h-36 bg-indigo-500/15 rounded-full blur-2xl pointer-events-none"></div>

        {/* Close button */}
        <button
          onClick={() => {
            sounds.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold text-gray-300 text-sm cursor-pointer transition-all hover:scale-110"
        >
          ✕
        </button>

        {/* Header with Pet dialogue */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-3xl shadow-inner animate-bounce">
            {petAvatar}
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-yellow-300 font-fredoka font-bold text-xs">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Đố Vui Cùng {petName}</span>
            </div>
            <h3 className="font-fredoka text-lg md:text-xl font-extrabold text-white">
              Thử Thách Trí Tuệ Nhanh
            </h3>
          </div>
        </div>

        {/* Pet speech bubble */}
        <div className="bg-white/10 border border-white/15 rounded-2xl p-4 mb-5 relative text-xs md:text-sm font-medium leading-relaxed text-indigo-100">
          <div className="absolute -top-2 left-8 w-3 h-3 bg-[#251A5A] border-t border-l border-white/15 rotate-45"></div>
          <p className="font-fredoka font-bold text-white text-sm md:text-base">
            "{currentQ.question}"
          </p>
        </div>

        {/* Options */}
        <div className="space-y-2.5 mb-5">
          {currentQ.options.map((opt) => {
            const isSelected = selectedOption === opt;
            const isTarget = opt === currentQ.answer;

            let btnStyle = 'bg-white/10 border-white/15 text-white hover:bg-white/20';
            if (isAnswered) {
              if (isTarget) {
                btnStyle = 'bg-emerald-500/30 border-emerald-400 text-emerald-200 ring-2 ring-emerald-400/50';
              } else if (isSelected && !isCorrect) {
                btnStyle = 'bg-rose-500/30 border-rose-400 text-rose-200';
              } else {
                btnStyle = 'bg-white/5 border-white/10 text-gray-400 opacity-60';
              }
            }

            return (
              <button
                key={opt}
                onClick={() => handleSelect(opt)}
                disabled={isAnswered}
                className={`w-full p-3.5 rounded-2xl border font-fredoka font-bold text-sm text-left transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
              >
                <span>{opt}</span>
                {isAnswered && isTarget && (
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Result & Explanation */}
        {isAnswered && (
          <div className={`p-4 rounded-2xl border mb-5 animate-fade-in ${isCorrect ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-100' : 'bg-amber-500/20 border-amber-400/40 text-amber-100'}`}>
            <div className="flex items-center gap-2 font-fredoka font-bold text-sm mb-1">
              <span>{isCorrect ? '🎉 Tuyệt vời! Bạn đã trả lời chính xác!' : '💡 Chưa chính xác rồi, đừng buồn nhé!'}</span>
            </div>
            <p className="text-xs leading-relaxed opacity-90 font-sans">
              {currentQ.explanation}
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-white/10">
          {isAnswered ? (
            isCorrect ? (
              <button
                onClick={handleClaim}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-400 text-purple-950 font-fredoka font-extrabold text-sm shadow-xl hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-1.5 transition-all"
              >
                <span>Nhận Thưởng (+30 xu, +25 Pet XP) 🌟</span>
              </button>
            ) : (
              <button
                onClick={handleRetry}
                className="px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-fredoka font-bold text-sm cursor-pointer transition-all"
              >
                <span>Thử câu hỏi khác 🔄</span>
              </button>
            )
          ) : (
            <span className="text-xs text-indigo-300 font-medium">
              Chọn 1 đáp án để nhận quà cùng thú cưng nhé!
            </span>
          )}
        </div>

      </div>
    </div>
  );
}
