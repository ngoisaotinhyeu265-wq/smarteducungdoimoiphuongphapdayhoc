import React, { useState } from 'react';
import { Trophy, Crown, Medal, Heart, Flame, Star, Award, Sparkles, Filter, School, Users } from 'lucide-react';
import { LeaderboardEntry, Student } from '../../types';
import { sounds } from '../../lib/audio';

interface MultiLeaderboardsProps {
  classLeaderboard: LeaderboardEntry[];
  schoolLeaderboard: LeaderboardEntry[];
  currentStudent: Student;
  onCheerStudent?: (entryId: string) => void;
}

export default function MultiLeaderboards({
  classLeaderboard,
  schoolLeaderboard,
  currentStudent,
  onCheerStudent
}: MultiLeaderboardsProps) {
  const [activeScope, setActiveScope] = useState<'class' | 'school' | 'pet' | 'streak'>('class');
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'all'>('week');
  const [cheeredIds, setCheeredIds] = useState<Record<string, boolean>>({});

  // Dynamic sorting based on active scope
  const getSortedList = (): LeaderboardEntry[] => {
    const baseList = activeScope === 'school' ? [...schoolLeaderboard] : [...classLeaderboard];
    
    if (activeScope === 'pet') {
      return baseList.sort((a, b) => (b.petLevel * 100 + b.xp) - (a.petLevel * 100 + a.xp));
    }
    if (activeScope === 'streak') {
      return baseList.sort((a, b) => b.streakDays - a.streakDays);
    }
    // Default by level & coins
    return baseList.sort((a, b) => (b.level * 1000 + b.coins) - (a.level * 1000 + a.coins));
  };

  const currentList = getSortedList();
  const top1 = currentList[0];
  const top2 = currentList[1];
  const top3 = currentList[2];
  const restList = currentList.slice(3);

  const handleCheer = (entry: LeaderboardEntry) => {
    sounds.playCoin();
    setCheeredIds(prev => ({ ...prev, [entry.id]: true }));
    entry.cheers += 1;
    if (onCheerStudent) {
      onCheerStudent(entry.id);
    }
  };

  // Find user rank
  const currentUserIndex = currentList.findIndex(e => e.studentId === currentStudent.id || e.isCurrentUser);
  const currentUserRank = currentUserIndex !== -1 ? currentUserIndex + 1 : 1;

  return (
    <div className="w-full space-y-6 select-none animate-fade-in text-left">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-yellow-900/40 via-amber-900/30 to-purple-900/50 backdrop-blur-xl p-6 rounded-[32px] border border-yellow-400/30 shadow-2xl text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-fredoka text-xl md:text-2xl font-extrabold text-yellow-300 flex items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-300" />
              <span>Bảng Vàng Danh Dự SmartEdu</span>
            </h2>
            <span className="bg-yellow-400/20 text-yellow-300 border border-yellow-300/40 text-xs font-fredoka font-bold px-3 py-1 rounded-full">
              Thứ hạng của bạn: #{currentUserRank}
            </span>
          </div>
          <p className="text-xs md:text-sm text-indigo-100 font-medium mt-1">
            Vinh danh những gương mặt xuất sắc nhất về học tập, chuỗi ngày rèn luyện và chăm sóc thú cưng!
          </p>
        </div>

        {/* Timeframe Selector */}
        <div className="flex items-center gap-1.5 bg-white/10 p-1.5 rounded-2xl border border-white/15">
          <button
            onClick={() => {
              sounds.playClick();
              setTimeframe('week');
            }}
            className={`px-3 py-1.5 rounded-xl font-fredoka font-bold text-xs transition-all cursor-pointer
              ${timeframe === 'week' ? 'bg-yellow-400 text-purple-950 shadow-md font-extrabold' : 'text-indigo-100 hover:text-white'}
            `}
          >
            Tuần này
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              setTimeframe('month');
            }}
            className={`px-3 py-1.5 rounded-xl font-fredoka font-bold text-xs transition-all cursor-pointer
              ${timeframe === 'month' ? 'bg-yellow-400 text-purple-950 shadow-md font-extrabold' : 'text-indigo-100 hover:text-white'}
            `}
          >
            Tháng này
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              setTimeframe('all');
            }}
            className={`px-3 py-1.5 rounded-xl font-fredoka font-bold text-xs transition-all cursor-pointer
              ${timeframe === 'all' ? 'bg-yellow-400 text-purple-950 shadow-md font-extrabold' : 'text-indigo-100 hover:text-white'}
            `}
          >
            Tất cả
          </button>
        </div>
      </div>

      {/* Scope Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => {
            sounds.playClick();
            setActiveScope('class');
          }}
          className={`px-4 py-2.5 rounded-2xl font-fredoka font-bold text-xs whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer
            ${activeScope === 'class' 
              ? 'bg-white text-indigo-700 shadow-xl scale-105 border border-white font-extrabold' 
              : 'bg-white/10 hover:bg-white/20 text-indigo-100 border border-white/15'
            }
          `}
        >
          <Users className="w-4 h-4" />
          <span>🎒 Bảng Xếp Hạng Lớp 3A1</span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            setActiveScope('school');
          }}
          className={`px-4 py-2.5 rounded-2xl font-fredoka font-bold text-xs whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer
            ${activeScope === 'school' 
              ? 'bg-white text-indigo-700 shadow-xl scale-105 border border-white font-extrabold' 
              : 'bg-white/10 hover:bg-white/20 text-indigo-100 border border-white/15'
            }
          `}
        >
          <School className="w-4 h-4" />
          <span>🏫 Toàn Trường Tân Định</span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            setActiveScope('pet');
          }}
          className={`px-4 py-2.5 rounded-2xl font-fredoka font-bold text-xs whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer
            ${activeScope === 'pet' 
              ? 'bg-white text-indigo-700 shadow-xl scale-105 border border-white font-extrabold' 
              : 'bg-white/10 hover:bg-white/20 text-indigo-100 border border-white/15'
            }
          `}
        >
          <span>🐾 Cao Thủ Thú Cưng</span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            setActiveScope('streak');
          }}
          className={`px-4 py-2.5 rounded-2xl font-fredoka font-bold text-xs whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer
            ${activeScope === 'streak' 
              ? 'bg-white text-indigo-700 shadow-xl scale-105 border border-white font-extrabold' 
              : 'bg-white/10 hover:bg-white/20 text-indigo-100 border border-white/15'
            }
          `}
        >
          <Flame className="w-4 h-4 text-orange-400" />
          <span>🔥 Vua Chuỗi Ngày Học</span>
        </button>
      </div>

      {/* Top 3 Champions Podium Display */}
      {top1 && (
        <div className="grid grid-cols-3 gap-2 md:gap-4 items-end pt-8 pb-4 text-center">
          
          {/* Rank 2 (Silver) */}
          {top2 && (
            <div className="bg-white/15 backdrop-blur-xl border border-slate-300/40 rounded-[28px] p-3 md:p-5 flex flex-col items-center justify-between min-h-[220px] shadow-xl relative order-1">
              <div className="absolute -top-6 w-10 h-10 rounded-full bg-slate-300 text-purple-950 font-fredoka font-extrabold text-sm flex items-center justify-center border-2 border-white shadow-lg">
                🥈 2
              </div>

              <div className="mt-2 space-y-1">
                <div className="w-14 h-14 md:w-16 md:h-16 mx-auto rounded-2xl bg-white/20 flex items-center justify-center text-3xl shadow-inner relative">
                  {top2.avatar}
                  <span className="absolute -bottom-1 -right-1 text-base">{top2.petAvatar}</span>
                </div>
                <h4 className="font-fredoka text-xs md:text-sm font-extrabold text-white truncate max-w-[100px] md:max-w-none">
                  {top2.name}
                </h4>
                <p className="text-[10px] text-indigo-200 font-bold">{top2.className}</p>
              </div>

              <div className="w-full pt-2 border-t border-white/10 space-y-1">
                <span className="font-fredoka text-xs md:text-sm font-bold text-yellow-300 block">
                  {activeScope === 'streak' ? `${top2.streakDays} ngày` : `${top2.coins} xu`}
                </span>
                <span className="text-[10px] text-indigo-200 block">Cấp {top2.level} ({top2.badgesCount} huy hiệu)</span>
              </div>
            </div>
          )}

          {/* Rank 1 (Gold - Central Highlight) */}
          <div className="bg-gradient-to-b from-yellow-400/25 via-amber-400/20 to-purple-900/40 backdrop-blur-xl border-2 border-yellow-300 rounded-[32px] p-4 md:p-6 flex flex-col items-center justify-between min-h-[260px] shadow-2xl relative order-2 scale-105">
            <div className="absolute -top-7 w-12 h-12 rounded-full bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-purple-950 font-fredoka font-extrabold text-base flex items-center justify-center border-2 border-white shadow-2xl animate-bounce">
              👑 1
            </div>

            <div className="mt-2 space-y-1">
              <div className="w-16 h-16 md:w-20 md:h-20 mx-auto rounded-3xl bg-yellow-400/30 border-2 border-yellow-300 flex items-center justify-center text-4xl shadow-inner relative">
                {top1.avatar}
                <span className="absolute -bottom-1 -right-1 text-xl">{top1.petAvatar}</span>
              </div>
              <h4 className="font-fredoka text-sm md:text-base font-extrabold text-yellow-300 truncate max-w-[120px] md:max-w-none">
                {top1.name}
              </h4>
              <p className="text-[11px] text-indigo-200 font-bold">{top1.className}</p>
            </div>

            <div className="w-full pt-2 border-t border-yellow-400/30 space-y-1">
              <span className="font-fredoka text-sm md:text-base font-extrabold text-yellow-300 block">
                {activeScope === 'streak' ? `🔥 ${top1.streakDays} ngày liên tục` : `⭐ ${top1.coins} xu vàng`}
              </span>
              <span className="text-[10px] text-emerald-300 font-bold block">
                Quán Quân Tuần • Cấp {top1.level}
              </span>
            </div>
          </div>

          {/* Rank 3 (Bronze) */}
          {top3 && (
            <div className="bg-white/15 backdrop-blur-xl border border-amber-600/40 rounded-[28px] p-3 md:p-5 flex flex-col items-center justify-between min-h-[200px] shadow-xl relative order-3">
              <div className="absolute -top-6 w-10 h-10 rounded-full bg-amber-700 text-amber-100 font-fredoka font-extrabold text-sm flex items-center justify-center border-2 border-white shadow-lg">
                🥉 3
              </div>

              <div className="mt-2 space-y-1">
                <div className="w-14 h-14 md:w-16 md:h-16 mx-auto rounded-2xl bg-white/20 flex items-center justify-center text-3xl shadow-inner relative">
                  {top3.avatar}
                  <span className="absolute -bottom-1 -right-1 text-base">{top3.petAvatar}</span>
                </div>
                <h4 className="font-fredoka text-xs md:text-sm font-extrabold text-white truncate max-w-[100px] md:max-w-none">
                  {top3.name}
                </h4>
                <p className="text-[10px] text-indigo-200 font-bold">{top3.className}</p>
              </div>

              <div className="w-full pt-2 border-t border-white/10 space-y-1">
                <span className="font-fredoka text-xs md:text-sm font-bold text-yellow-300 block">
                  {activeScope === 'streak' ? `${top3.streakDays} ngày` : `${top3.coins} xu`}
                </span>
                <span className="text-[10px] text-indigo-200 block">Cấp {top3.level} ({top3.badgesCount} huy hiệu)</span>
              </div>
            </div>
          )}

        </div>
      )}

      {/* Rest of the Class Leaderboard Table */}
      <div className="bg-white/15 backdrop-blur-xl rounded-[32px] border border-white/20 p-5 md:p-6 shadow-2xl space-y-3 text-white">
        <h3 className="font-fredoka text-base font-extrabold text-white mb-2 flex items-center justify-between">
          <span>Danh Sách Thứ Hạng Đầy Đủ</span>
          <span className="text-xs text-indigo-200 font-bold font-sans">Tổng cộng: {currentList.length} học sinh</span>
        </h3>

        <div className="space-y-2.5">
          {currentList.map((entry, idx) => {
            const isUser = entry.studentId === currentStudent.id || entry.isCurrentUser;
            const hasCheered = cheeredIds[entry.id];

            return (
              <div
                key={entry.id}
                className={`p-3.5 md:p-4 rounded-2xl border flex items-center justify-between gap-3 transition-all
                  ${isUser 
                    ? 'bg-yellow-400/20 border-yellow-300 ring-2 ring-yellow-400/40 shadow-lg' 
                    : 'bg-white/10 border-white/15 hover:bg-white/15'
                  }
                `}
              >
                <div className="flex items-center gap-3 md:gap-4 min-w-0">
                  {/* Rank Badge */}
                  <span className={`w-8 h-8 rounded-full font-fredoka font-extrabold text-xs flex items-center justify-center border shrink-0
                    ${idx === 0 ? 'bg-yellow-400 text-purple-950 border-white' :
                      idx === 1 ? 'bg-slate-300 text-purple-950 border-white' :
                      idx === 2 ? 'bg-amber-700 text-white border-white' :
                      'bg-white/10 text-indigo-200 border-white/10'}
                  `}>
                    {idx + 1}
                  </span>

                  {/* Student Avatar */}
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-2xl shadow-inner shrink-0 relative">
                    {entry.avatar}
                    <span className="absolute -bottom-1 -right-1 text-xs" title={`Thú cưng: ${entry.petName}`}>
                      {entry.petAvatar}
                    </span>
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-fredoka text-sm font-extrabold text-white truncate">
                        {entry.name}
                      </h4>
                      {isUser && (
                        <span className="bg-emerald-500 text-white text-[9px] font-fredoka font-extrabold px-2 py-0.2 rounded-full">
                          BẠN
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-indigo-200 font-bold flex items-center gap-2">
                      <span>{entry.className}</span>
                      <span>•</span>
                      <span>Pet: {entry.petName} (Cấp {entry.petLevel})</span>
                    </p>
                  </div>
                </div>

                {/* Score & Cheer Button */}
                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    <span className="font-fredoka text-xs md:text-sm font-bold text-yellow-300 flex items-center justify-end gap-1">
                      <Star className="w-3.5 h-3.5 fill-yellow-400" />
                      {entry.coins} xu
                    </span>
                    <span className="text-[10px] text-indigo-200 font-bold block">
                      Cấp {entry.level} • {entry.badgesCount} 🎖️
                    </span>
                  </div>

                  {/* Cheer button */}
                  <button
                    onClick={() => handleCheer(entry)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-fredoka font-bold flex items-center gap-1 transition-all cursor-pointer
                      ${hasCheered 
                        ? 'bg-pink-500 text-white' 
                        : 'bg-white/15 hover:bg-white/25 text-pink-300 hover:scale-105'
                      }
                    `}
                    title="Gửi tim cổ vũ bạn bè!"
                  >
                    <Heart className={`w-3.5 h-3.5 ${hasCheered ? 'fill-white' : 'fill-pink-400'}`} />
                    <span>{entry.cheers}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
