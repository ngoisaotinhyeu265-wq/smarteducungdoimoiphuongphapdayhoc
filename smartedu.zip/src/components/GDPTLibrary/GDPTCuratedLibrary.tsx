/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  BookOpen, Sparkles, Gamepad2, Search, Filter, CheckCircle2, 
  Plus, Check, Play, Eye, Download, Copy, Trash2, Award, 
  HelpCircle, ChevronRight, Layers, ArrowRight, X, ExternalLink,
  Flame, Star, Lightbulb, Compass, Share2, Printer
} from 'lucide-react';
import { 
  GDPT_CATEGORIES, 
  GDPT_CURATED_TOPICS, 
  GDPTCategoryKey, 
  GDPTTopic,
  GDPTCategoryInfo
} from '../../data/gdpt2018CuratedLibrary';
import { Question, GameType, SubjectType } from '../../types';
import { sounds } from '../../lib/audio';

interface GDPTCuratedLibraryProps {
  onNavigateToGames: (startType?: GameType, customQuestions?: Question[]) => void;
  onAddQuestionsToBank: (questions: Question[]) => void;
  onNavigateToPlanner?: (params?: any) => void;
}

export default function GDPTCuratedLibrary({
  onNavigateToGames,
  onAddQuestionsToBank,
  onNavigateToPlanner
}: GDPTCuratedLibraryProps) {
  // Filter states
  const [selectedCategory, setSelectedCategory] = useState<GDPTCategoryKey | 'all'>('all');
  const [selectedGrade, setSelectedGrade] = useState<number | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'topics' | 'questions'>('topics');
  const [selectedCognitiveLevel, setSelectedCognitiveLevel] = useState<string>('all');

  // Selected questions for game incorporation
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<string[]>([]);
  
  // Topic detail modal state
  const [activeTopicDetail, setActiveTopicDetail] = useState<GDPTTopic | null>(null);

  // Game Launcher Modal State
  const [isGameLauncherOpen, setIsGameLauncherOpen] = useState(false);
  const [pendingGameQuestions, setPendingGameQuestions] = useState<Question[]>([]);

  // Toast / Feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Filter topics
  const filteredTopics = useMemo(() => {
    return GDPT_CURATED_TOPICS.filter(topic => {
      // Category filter
      if (selectedCategory !== 'all' && topic.categoryKey !== selectedCategory) {
        return false;
      }
      // Grade filter
      if (selectedGrade !== 'all' && topic.grade !== selectedGrade) {
        return false;
      }
      // Cognitive level filter (if matching any question)
      if (selectedCognitiveLevel !== 'all') {
        const hasLevel = topic.questions.some(q => q.cognitiveLevel === selectedCognitiveLevel);
        if (!hasLevel) return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchTitle = topic.title.toLowerCase().includes(q);
        const matchUnit = topic.unitOrChapter.toLowerCase().includes(q);
        const matchCode = topic.standardCode.toLowerCase().includes(q);
        const matchSubject = topic.subject.toLowerCase().includes(q);
        const matchOutcome = topic.learningOutcomes.some(o => o.toLowerCase().includes(q));
        const matchQuestion = topic.questions.some(qn => qn.text.toLowerCase().includes(q) || (qn.tags && qn.tags.some(t => t.toLowerCase().includes(q))));
        return matchTitle || matchUnit || matchCode || matchSubject || matchOutcome || matchQuestion;
      }
      return true;
    });
  }, [selectedCategory, selectedGrade, selectedCognitiveLevel, searchQuery]);

  // Flattened questions from filtered topics
  const allFilteredQuestions = useMemo(() => {
    const list: { question: Question; topic: GDPTTopic }[] = [];
    filteredTopics.forEach(topic => {
      topic.questions.forEach(q => {
        if (selectedCognitiveLevel === 'all' || q.cognitiveLevel === selectedCognitiveLevel) {
          list.push({ question: q, topic });
        }
      });
    });
    return list;
  }, [filteredTopics, selectedCognitiveLevel]);

  // Selected Question Objects
  const selectedQuestions = useMemo(() => {
    const allQs = GDPT_CURATED_TOPICS.flatMap(t => t.questions);
    return allQs.filter(q => selectedQuestionIds.includes(q.id));
  }, [selectedQuestionIds]);

  // Toggle single question selection
  const handleToggleQuestion = (qId: string) => {
    sounds.playClick();
    setSelectedQuestionIds(prev => {
      if (prev.includes(qId)) {
        return prev.filter(id => id !== qId);
      } else {
        return [...prev, qId];
      }
    });
  };

  // Select all questions in a specific topic
  const handleSelectTopicQuestions = (topic: GDPTTopic) => {
    sounds.playClick();
    const topicQIds = topic.questions.map(q => q.id);
    const allSelected = topicQIds.every(id => selectedQuestionIds.includes(id));
    
    if (allSelected) {
      // Unselect topic questions
      setSelectedQuestionIds(prev => prev.filter(id => !topicQIds.includes(id)));
      showToast(`Đã bỏ chọn các câu hỏi của "${topic.title}"`);
    } else {
      // Select all topic questions
      setSelectedQuestionIds(prev => Array.from(new Set([...prev, ...topicQIds])));
      sounds.playLevelUp();
      showToast(`✨ Đã thêm ${topic.questions.length} câu hỏi từ "${topic.title}" vào Khay Game!`);
    }
  };

  // Select all filtered questions
  const handleSelectAllFiltered = () => {
    sounds.playLevelUp();
    const filteredQIds = allFilteredQuestions.map(item => item.question.id);
    setSelectedQuestionIds(prev => Array.from(new Set([...prev, ...filteredQIds])));
    showToast(`Đã chọn toàn bộ ${filteredQIds.length} câu hỏi hiển thị!`);
  };

  // Clear selection
  const handleClearSelection = () => {
    sounds.playClick();
    setSelectedQuestionIds([]);
  };

  // Launch Game with chosen questions
  const handleOpenGameLauncher = (questionsToPlay?: Question[]) => {
    sounds.playClick();
    const qs = questionsToPlay && questionsToPlay.length > 0 ? questionsToPlay : selectedQuestions;
    if (qs.length === 0) {
      alert('Vui lòng chọn ít nhất 1 câu hỏi hoặc 1 chủ đề để bắt đầu trò chơi!');
      return;
    }
    setPendingGameQuestions(qs);
    setIsGameLauncherOpen(true);
  };

  // Launch specific game type
  const handleLaunchGameMode = (gameType: GameType) => {
    sounds.playLevelUp();
    setIsGameLauncherOpen(false);
    onNavigateToGames(gameType, pendingGameQuestions);
  };

  // Add selected questions to Question Bank
  const handleSaveSelectedToBank = () => {
    if (selectedQuestions.length === 0) {
      alert('Vui lòng chọn câu hỏi trước khi thêm vào Ngân hàng câu hỏi!');
      return;
    }
    sounds.playLevelUp();
    onAddQuestionsToBank(selectedQuestions);
    showToast(`🎉 Đã thêm thành công ${selectedQuestions.length} câu hỏi vào Ngân hàng câu hỏi cá nhân!`);
  };

  // Quick Play Whole Topic
  const handleQuickPlayTopic = (topic: GDPTTopic, defaultGame: GameType = 'quiz') => {
    sounds.playLevelUp();
    onNavigateToGames(defaultGame, topic.questions);
  };

  // Print / Export worksheet
  const handlePrintWorksheet = () => {
    const qsToExport = selectedQuestions.length > 0 ? selectedQuestions : allFilteredQuestions.map(i => i.question);
    if (qsToExport.length === 0) {
      alert('Không có câu hỏi nào để xuất!');
      return;
    }
    
    // Create printable window
    const printWin = window.open('', '_blank');
    if (!printWin) return;
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Phiếu Bài Tập GDPT 2018 - SmartEdu</title>
        <style>
          body { font-family: 'Times New Roman', serif; padding: 24px; color: #111; line-height: 1.5; }
          .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 12px; }
          .title { font-size: 18pt; font-weight: bold; text-transform: uppercase; margin: 4px 0; }
          .subtitle { font-size: 12pt; font-style: italic; color: #555; }
          .student-info { display: flex; justify-content: space-between; margin: 15px 0 25px 0; font-size: 11pt; }
          .q-box { margin-bottom: 16px; page-break-inside: avoid; }
          .q-title { font-weight: bold; font-size: 12pt; }
          .options-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 6px; padding-left: 15px; }
          .opt { font-size: 11pt; }
          .footer { margin-top: 30px; text-align: right; font-style: italic; font-size: 10pt; }
          @media print {
            button { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div style="font-size: 11pt; font-weight: bold;">BỘ GIÁO DỤC VÀ ĐÀO TẠO - CHƯƠNG TRÌNH GDPT 2018</div>
          <div class="title">PHIẾU BÀI TẬP VÀ ÔN TẬP TRÒ CHƠI HỌC TẬP</div>
          <div class="subtitle">Trích xuất từ Kho Học Liệu Chuẩn Hóa SmartEdu Primary</div>
        </div>

        <div class="student-info">
          <div>Họ và tên học sinh: ..............................................................</div>
          <div>Lớp: .....................</div>
          <div>Điểm số: ................</div>
        </div>

        <div>
          ${qsToExport.map((q, idx) => `
            <div class="q-box">
              <div class="q-title">Câu ${idx + 1}: ${q.text} <span style="font-weight: normal; font-size: 10pt; color: #666;">(${q.subject} - Lớp ${q.grade} | ${q.cognitiveLevel || 'Thông hiểu'})</span></div>
              ${q.options && q.options.length > 0 ? `
                <div class="options-grid">
                  ${q.options.map((opt, oIdx) => `
                    <div class="opt">${String.fromCharCode(65 + oIdx)}. ${opt}</div>
                  `).join('')}
                </div>
              ` : `
                <div style="height: 40px; border-bottom: 1px dotted #999; margin-top: 10px;">Trả lời: ............................................................................................................................</div>
              `}
            </div>
          `).join('')}
        </div>

        <div class="footer">
          <div>--- Chúc các em học sinh làm bài vui vẻ và đạt kết quả cao! ---</div>
          <div>Giáo viên chủ nhiệm duyệt & biên soạn</div>
        </div>

        <script>
          window.print();
        </script>
      </body>
      </html>
    `;

    printWin.document.write(html);
    printWin.document.close();
  };

  const gameModeCatalog = [
    { id: 'quiz', name: '🎯 Trắc Nghiệm 15 Giây', desc: 'Đấu trí nghẹt thở với đồng hồ bấm giờ 15s', icon: '⚡', color: 'from-purple-500 to-indigo-600' },
    { id: 'frog', name: '🐸 Ếch Xanh Qua Sông', desc: 'Trả lời đúng để giúp chú ếch nhảy qua các lá sen', icon: '🐸', color: 'from-emerald-500 to-teal-600' },
    { id: 'wheel', name: '🎡 Vòng Quay Kỳ Diệu', desc: 'Vòng quay may mắn chọn ngẫu nhiên câu hỏi & gọi học sinh', icon: '🎡', color: 'from-amber-500 to-orange-600' },
    { id: 'memory', name: '🧩 Lật Thẻ Trí Nhớ', desc: 'Ghép cặp câu hỏi - câu trả lời tương ứng qua trí nhớ', icon: '🧩', color: 'from-cyan-500 to-blue-600' },
    { id: 'balloon', name: '🎈 Bắn Bóng Bay (Balloon Pop)', desc: 'Bắn bong bóng bay chứa câu trả lời chính xác', icon: '🎈', color: 'from-pink-500 to-rose-600' },
    { id: 'flashcard', name: '🎴 Thẻ Flashcards Trực Quan', desc: 'Lật mở thẻ học nhanh, ghi nhớ kiến thức cốt lõi', icon: '🎴', color: 'from-indigo-500 to-blue-700' },
    { id: 'fill_blank', name: '✏️ Điền Từ & Giải Ô Chữ', desc: 'Gõ từ khóa, điền chỗ trống và giải đố chữ', icon: '✏️', color: 'from-violet-500 to-purple-700' }
  ];

  return (
    <div className="flex flex-col gap-6 animate-fade-in pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-gray-900/95 text-white px-5 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 animate-bounce font-fredoka text-sm">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner & Introduction */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 text-white rounded-3xl p-6 md:p-8 shadow-xl relative overflow-hidden border border-indigo-400/20">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2.5 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 bg-amber-400 text-amber-950 rounded-full text-xs font-black uppercase tracking-wider font-fredoka flex items-center gap-1 shadow-sm">
                <Award className="w-3.5 h-3.5" /> CHUẨN CT GDPT 2018
              </span>
              <span className="px-3 py-1 bg-emerald-500/30 text-emerald-200 border border-emerald-400/30 rounded-full text-xs font-bold font-fredoka">
                5 Môn Học Cốt Lõi (Lớp 1 - 5)
              </span>
              <span className="px-3 py-1 bg-cyan-500/30 text-cyan-200 border border-cyan-400/30 rounded-full text-xs font-bold font-fredoka">
                Tích Hợp 7+ Trò Chơi Lớp Học 🎮
              </span>
            </div>
            
            <h1 className="text-2xl md:text-3xl font-extrabold font-fredoka text-white tracking-tight flex items-center gap-3">
              <span>🏛️ Kho Học Liệu & Chủ Đề GDPT 2018</span>
            </h1>
            
            <p className="text-indigo-100 text-xs md:text-sm leading-relaxed">
              Thư viện học liệu tuyển chọn chuẩn hóa theo <span className="text-amber-300 font-bold">Chương trình Giáo dục phổ thông 2018</span>. Thầy cô dễ dàng duyệt theo chủ đề, khối lớp, chọn lọc câu hỏi và <strong>tích hợp ngay vào các trò chơi lớp học (Frog Jump, Quiz 15s, Vòng quay, Memory...)</strong> để khởi động hoặc củng cố bài học!
            </p>
          </div>

          {/* Quick Launch Action Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={() => handleOpenGameLauncher()}
              disabled={selectedQuestionIds.length === 0}
              className={`px-5 py-3 rounded-2xl font-fredoka font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg cursor-pointer ${
                selectedQuestionIds.length > 0
                  ? 'bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 hover:from-amber-500 hover:to-orange-500 text-gray-950 hover:scale-105 shadow-amber-500/30'
                  : 'bg-white/10 text-white/40 cursor-not-allowed border border-white/10'
              }`}
            >
              <Gamepad2 className="w-5 h-5" />
              <span>Chơi Game Với ({selectedQuestionIds.length}) Câu Đã Chọn</span>
            </button>

            <button
              onClick={handlePrintWorksheet}
              className="px-4 py-3 bg-white/15 hover:bg-white/25 text-white border border-white/20 rounded-2xl font-fredoka font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              title="In phiếu bài tập hoặc xuất bản in"
            >
              <Printer className="w-4 h-4 text-cyan-300" />
              <span>Xuất Phiếu Bài Tập</span>
            </button>
          </div>
        </div>

        {/* 5 Core Subject Shortcut Pills */}
        <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {GDPT_CATEGORIES.map(cat => {
            const isSelected = selectedCategory === cat.key;
            return (
              <button
                key={cat.key}
                onClick={() => {
                  sounds.playClick();
                  setSelectedCategory(cat.key);
                }}
                className={`p-3 rounded-2xl text-left transition-all cursor-pointer border flex flex-col justify-between ${
                  isSelected 
                    ? 'bg-white text-gray-900 border-white shadow-lg scale-[1.03]' 
                    : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xl">{cat.icon}</span>
                  <span className={`text-[10px] font-fredoka font-bold px-2 py-0.5 rounded-full ${isSelected ? 'bg-indigo-100 text-indigo-800' : 'bg-white/15 text-white/90'}`}>
                    {cat.name}
                  </span>
                </div>
                <div className="mt-2">
                  <div className="font-fredoka font-bold text-sm line-clamp-1">{cat.vietnameseName}</div>
                  <div className={`text-[11px] line-clamp-1 ${isSelected ? 'text-gray-600' : 'text-indigo-200'}`}>
                    {cat.coreCompetencies[0]}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter and View Bar */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-indigo-100 flex flex-col gap-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          
          {/* Subject Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
            <button
              onClick={() => { sounds.playClick(); setSelectedCategory('all'); }}
              className={`px-3.5 py-2 rounded-xl font-fredoka font-bold text-xs shrink-0 transition-all cursor-pointer ${
                selectedCategory === 'all'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              🌟 Tất cả 5 môn
            </button>
            {GDPT_CATEGORIES.map(cat => (
              <button
                key={cat.key}
                onClick={() => { sounds.playClick(); setSelectedCategory(cat.key); }}
                className={`px-3.5 py-2 rounded-xl font-fredoka font-bold text-xs shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
                  selectedCategory === cat.key
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.vietnameseName}</span>
              </button>
            ))}
          </div>

          {/* Grade Selector */}
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-xs font-bold text-gray-500 font-fredoka mr-1">Khối lớp:</span>
            {(['all', 1, 2, 3, 4, 5] as const).map(gr => (
              <button
                key={gr}
                onClick={() => { sounds.playClick(); setSelectedGrade(gr); }}
                className={`px-3 py-1.5 rounded-lg font-fredoka font-bold text-xs transition-all cursor-pointer ${
                  selectedGrade === gr
                    ? 'bg-purple-600 text-white shadow-xs'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
                }`}
              >
                {gr === 'all' ? 'Tất cả' : `Lớp ${gr}`}
              </button>
            ))}
          </div>
        </div>

        {/* Search, Cognitive Level, and View Mode Switch */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-gray-100">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm theo tên chủ đề, từ khóa, YCCĐ, câu hỏi, kiến thức..."
              className="w-full pl-10 pr-4 py-2.5 bg-gray-50 hover:bg-gray-100/80 focus:bg-white border border-gray-200 focus:border-indigo-500 rounded-xl text-xs font-medium text-gray-800 outline-none transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Cognitive Level Filter */}
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-xs font-bold text-gray-500 font-fredoka">Mức độ:</span>
            <select
              value={selectedCognitiveLevel}
              onChange={(e) => { sounds.playClick(); setSelectedCognitiveLevel(e.target.value); }}
              className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-fredoka font-bold text-gray-700 outline-none cursor-pointer"
            >
              <option value="all">Tất cả mức độ</option>
              <option value="Nhận biết">🟢 Nhận biết</option>
              <option value="Thông hiểu">🟡 Thông hiểu</option>
              <option value="Vận dụng">🔴 Vận dụng</option>
            </select>
          </div>

          {/* View Mode Toggle (Topics vs Question Bank) */}
          <div className="bg-gray-100 p-1 rounded-xl flex items-center gap-1 shrink-0">
            <button
              onClick={() => { sounds.playClick(); setViewMode('topics'); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-fredoka font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'topics' ? 'bg-white text-indigo-700 shadow-xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Gói Chủ Đề ({filteredTopics.length})</span>
            </button>
            <button
              onClick={() => { sounds.playClick(); setViewMode('questions'); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-fredoka font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'questions' ? 'bg-white text-indigo-700 shadow-xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Tất Cả Câu Hỏi ({allFilteredQuestions.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Floating Selection Bar (if items selected) */}
      {selectedQuestionIds.length > 0 && (
        <div className="bg-gradient-to-r from-indigo-700 via-purple-700 to-pink-700 text-white p-4 rounded-2xl shadow-xl flex flex-wrap items-center justify-between gap-4 animate-slide-up sticky top-4 z-30 border border-white/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center font-fredoka font-black text-amber-300 text-lg shadow-inner">
              {selectedQuestionIds.length}
            </div>
            <div>
              <div className="font-fredoka font-bold text-sm text-white flex items-center gap-2">
                <span>Đã chọn {selectedQuestionIds.length} câu hỏi GDPT 2018</span>
                <span className="px-2 py-0.5 bg-amber-400 text-amber-950 rounded-md text-[10px] font-black uppercase">
                  Sẵn sàng chơi
                </span>
              </div>
              <div className="text-indigo-200 text-xs">
                Có thể chơi ngay ở 7 chế độ game hoặc lưu vào Ngân hàng câu hỏi cá nhân.
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleOpenGameLauncher()}
              className="px-4 py-2 bg-gradient-to-r from-amber-400 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-gray-950 font-fredoka font-black text-xs rounded-xl shadow-lg transition-all cursor-pointer flex items-center gap-1.5 hover:scale-105"
            >
              <Gamepad2 className="w-4 h-4 text-gray-900" />
              <span>Chơi Game Ngay 🚀</span>
            </button>

            <button
              onClick={handleSaveSelectedToBank}
              className="px-3.5 py-2 bg-white/20 hover:bg-white/30 text-white font-fredoka font-bold text-xs rounded-xl border border-white/30 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-300" />
              <span>Lưu Vào Ngân Hàng</span>
            </button>

            <button
              onClick={handleClearSelection}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white/80 hover:text-white font-fredoka font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1"
              title="Xóa lựa chọn"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Bỏ chọn</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      {viewMode === 'topics' ? (
        /* TOPIC PACKAGES VIEW */
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-extrabold font-fredoka text-gray-800 flex items-center gap-2">
              <span>📚 Danh Sách Gói Chủ Đề Tuyển Chọn</span>
              <span className="text-xs bg-indigo-100 text-indigo-800 font-bold px-2.5 py-0.5 rounded-full">
                {filteredTopics.length} chủ đề
              </span>
            </h2>

            <button
              onClick={handleSelectAllFiltered}
              className="text-xs font-fredoka font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Chọn tất cả ({allFilteredQuestions.length} câu hỏi)</span>
            </button>
          </div>

          {filteredTopics.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-gray-300 space-y-3">
              <div className="text-4xl">🔍</div>
              <h3 className="font-fredoka font-bold text-gray-700">Không tìm thấy chủ đề phù hợp</h3>
              <p className="text-xs text-gray-500 max-w-md mx-auto">
                Vui lòng thử chọn khối lớp khác hoặc tìm kiếm với từ khóa tổng quát hơn.
              </p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedGrade('all');
                  setSelectedCognitiveLevel('all');
                  setSearchQuery('');
                }}
                className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-fredoka font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Xóa tất cả bộ lọc
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredTopics.map((topic) => {
                const topicQIds = topic.questions.map(q => q.id);
                const selectedCount = topicQIds.filter(id => selectedQuestionIds.includes(id)).length;
                const isFullySelected = selectedCount === topic.questions.length && topic.questions.length > 0;
                
                return (
                  <div
                    key={topic.id}
                    className={`bg-white rounded-3xl border transition-all flex flex-col justify-between overflow-hidden relative shadow-xs hover:shadow-md hover:-translate-y-1 ${
                      isFullySelected ? 'border-indigo-500 ring-2 ring-indigo-500/20' : 'border-gray-200/80 hover:border-indigo-300'
                    }`}
                  >
                    {/* Top Header color bar */}
                    <div className="p-5 pb-3">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className={`text-[11px] font-fredoka font-extrabold px-2.5 py-1 rounded-lg ${topic.badgeBg}`}>
                            {topic.icon} {topic.subject} • Lớp {topic.grade}
                          </span>
                          <span className="text-[10px] font-fredoka font-bold px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md">
                            {topic.standardCode}
                          </span>
                        </div>

                        {/* Checkbox select all questions of this topic */}
                        <button
                          onClick={() => handleSelectTopicQuestions(topic)}
                          className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                            isFullySelected 
                              ? 'bg-indigo-600 text-white shadow-sm' 
                              : selectedCount > 0 
                              ? 'bg-indigo-100 text-indigo-700 border border-indigo-300'
                              : 'bg-gray-100 hover:bg-gray-200 text-gray-400'
                          }`}
                          title={isFullySelected ? 'Bỏ chọn toàn bộ câu hỏi' : 'Chọn toàn bộ câu hỏi vào Game'}
                        >
                          {isFullySelected ? (
                            <Check className="w-4 h-4 stroke-[3]" />
                          ) : selectedCount > 0 ? (
                            <span className="text-xs font-black">{selectedCount}</span>
                          ) : (
                            <Plus className="w-4 h-4" />
                          )}
                        </button>
                      </div>

                      <h3 className="font-fredoka font-bold text-base text-gray-900 line-clamp-2 leading-snug mt-1">
                        {topic.title}
                      </h3>

                      <p className="text-[11px] text-gray-500 mt-1 line-clamp-1">
                        📖 {topic.unitOrChapter}
                      </p>

                      {/* Learning Outcomes Snippet */}
                      <div className="mt-3 bg-gray-50 rounded-2xl p-3 border border-gray-100 space-y-1.5">
                        <div className="text-[10px] font-fredoka font-bold text-gray-400 uppercase tracking-wider">
                          Yêu cầu cần đạt (GDPT 2018):
                        </div>
                        <ul className="text-xs text-gray-700 space-y-1">
                          {topic.learningOutcomes.slice(0, 2).map((outcome, idx) => (
                            <li key={idx} className="flex items-start gap-1.5 line-clamp-2">
                              <span className="text-indigo-500 font-bold shrink-0">•</span>
                              <span className="text-[11px]">{outcome}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Recommended Games */}
                      <div className="mt-3 flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-bold text-gray-400 font-fredoka">Game phù hợp:</span>
                        {topic.recommendedGames.slice(0, 3).map((gm) => (
                          <span
                            key={gm}
                            className="text-[10px] font-fredoka font-bold px-2 py-0.5 bg-purple-50 text-purple-700 border border-purple-100 rounded-md"
                          >
                            {gm === 'quiz' ? '🎯 Quiz' : gm === 'frog' ? '🐸 Ếch nhảy' : gm === 'wheel' ? '🎡 Vòng quay' : gm === 'memory' ? '🧩 Lật thẻ' : gm === 'balloon' ? '🎈 Bắn bóng' : gm === 'flashcard' ? '🎴 Flashcard' : '✏️ Ô chữ'}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Bottom Action Footer */}
                    <div className="p-4 bg-gray-50/80 border-t border-gray-100 flex items-center justify-between gap-2">
                      <button
                        onClick={() => {
                          sounds.playClick();
                          setActiveTopicDetail(topic);
                        }}
                        className="px-3 py-2 bg-white hover:bg-gray-100 text-gray-700 border border-gray-200 font-fredoka font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Xem chi tiết & ({topic.questions.length}) câu hỏi</span>
                      </button>

                      <button
                        onClick={() => handleQuickPlayTopic(topic, topic.recommendedGames[0] || 'quiz')}
                        className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-fredoka font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1.5 hover:scale-105"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Chơi Ngay 🎮</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* QUESTIONS LIST VIEW */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-extrabold font-fredoka text-gray-800 flex items-center gap-2">
              <span>📖 Danh Sách Tất Cả Câu Hỏi Tuyển Chọn</span>
              <span className="text-xs bg-indigo-100 text-indigo-800 font-bold px-2.5 py-0.5 rounded-full">
                {allFilteredQuestions.length} câu hỏi
              </span>
            </h2>

            <button
              onClick={handleSelectAllFiltered}
              className="text-xs font-fredoka font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Chọn toàn bộ {allFilteredQuestions.length} câu</span>
            </button>
          </div>

          <div className="space-y-3">
            {allFilteredQuestions.map(({ question: q, topic }, idx) => {
              const isSelected = selectedQuestionIds.includes(q.id);

              return (
                <div
                  key={q.id}
                  className={`bg-white rounded-2xl p-4 border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs ${
                    isSelected ? 'border-indigo-500 bg-indigo-50/20 ring-1 ring-indigo-500' : 'border-gray-200 hover:border-indigo-200'
                  }`}
                >
                  <div className="flex items-start gap-3.5 flex-1">
                    {/* Checkbox */}
                    <button
                      onClick={() => handleToggleQuestion(q.id)}
                      className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all cursor-pointer shrink-0 mt-0.5 ${
                        isSelected ? 'bg-indigo-600 text-white' : 'bg-gray-100 hover:bg-gray-200 text-transparent border border-gray-300'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </button>

                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-[10px] font-fredoka font-extrabold px-2 py-0.5 rounded-md ${topic.badgeBg}`}>
                          {q.subject} • Lớp {q.grade}
                        </span>
                        <span className="text-[10px] font-fredoka font-bold px-2 py-0.5 bg-gray-100 text-gray-700 rounded-md">
                          {q.cognitiveLevel || 'Thông hiểu'}
                        </span>
                        <span className="text-[10px] text-gray-400 font-medium line-clamp-1">
                          📌 {topic.title}
                        </span>
                      </div>

                      <div className="font-fredoka font-bold text-sm text-gray-900">
                        {idx + 1}. {q.text}
                      </div>

                      {/* Options Preview */}
                      {q.options && q.options.length > 0 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                          {q.options.map((opt, oIdx) => {
                            const isCorrect = opt === q.answer;
                            return (
                              <div
                                key={oIdx}
                                className={`text-[11px] px-2.5 py-1 rounded-lg border font-medium flex items-center gap-1.5 ${
                                  isCorrect 
                                    ? 'bg-emerald-50 text-emerald-900 border-emerald-300 font-bold' 
                                    : 'bg-gray-50 text-gray-600 border-gray-100'
                                }`}
                              >
                                <span className="font-bold opacity-60">{String.fromCharCode(65 + oIdx)}.</span>
                                <span>{opt}</span>
                                {isCorrect && <CheckCircle2 className="w-3 h-3 text-emerald-600 ml-auto shrink-0" />}
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Explanation Snippet */}
                      {q.explanation && (
                        <div className="text-[11px] text-gray-500 bg-amber-50/60 border border-amber-200/50 rounded-lg p-2 mt-1">
                          <strong className="text-amber-800 font-fredoka">💡 Giải thích:</strong> {q.explanation}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                    <button
                      onClick={() => {
                        sounds.playLevelUp();
                        onNavigateToGames('quiz', [q]);
                      }}
                      className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-fredoka font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Chơi thử</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TOPIC DETAIL MODAL */}
      {activeTopicDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full overflow-hidden border border-indigo-100 flex flex-col max-h-[90vh] animate-scale-in">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-indigo-800 to-purple-800 text-white p-6 relative">
              <button
                onClick={() => setActiveTopicDetail(null)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-fredoka font-bold px-2.5 py-0.5 bg-amber-400 text-amber-950 rounded-md">
                  {activeTopicDetail.subject} • Lớp {activeTopicDetail.grade}
                </span>
                <span className="text-xs font-fredoka font-bold px-2 py-0.5 bg-white/20 text-white rounded-md">
                  Mã YCCĐ: {activeTopicDetail.standardCode}
                </span>
              </div>

              <h2 className="text-xl font-extrabold font-fredoka text-white">
                {activeTopicDetail.title}
              </h2>
              <p className="text-xs text-indigo-200 mt-1">
                Bộ sách: {activeTopicDetail.bookSeries} | {activeTopicDetail.unitOrChapter}
              </p>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5">
              {/* Learning Outcomes */}
              <div className="bg-indigo-50/70 border border-indigo-100 rounded-2xl p-4 space-y-2">
                <h4 className="font-fredoka font-bold text-sm text-indigo-900 flex items-center gap-2">
                  <Award className="w-4 h-4 text-indigo-600" />
                  <span>Yêu cầu cần đạt chuẩn GDPT 2018:</span>
                </h4>
                <ul className="space-y-1.5 text-xs text-indigo-950 pl-2">
                  {activeTopicDetail.learningOutcomes.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-indigo-500 font-bold">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Core Pedagogical Notes */}
              {activeTopicDetail.conceptNotes && (
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-1.5">
                  <h4 className="font-fredoka font-bold text-xs text-amber-900 flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-amber-600" />
                    <span>Ghi nhớ trọng tâm & Mẹo sư phạm:</span>
                  </h4>
                  <p className="text-xs text-amber-950 leading-relaxed">
                    {activeTopicDetail.conceptNotes}
                  </p>
                </div>
              )}

              {/* Questions List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-fredoka font-bold text-sm text-gray-800 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-indigo-600" />
                    <span>Bộ ({activeTopicDetail.questions.length}) câu hỏi chuẩn hóa:</span>
                  </h4>

                  <button
                    onClick={() => handleSelectTopicQuestions(activeTopicDetail)}
                    className="text-xs font-fredoka font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                  >
                    + Chọn toàn bộ câu hỏi vào Game
                  </button>
                </div>

                <div className="space-y-3">
                  {activeTopicDetail.questions.map((q, idx) => {
                    const isSelected = selectedQuestionIds.includes(q.id);
                    return (
                      <div
                        key={q.id}
                        className={`p-3.5 rounded-2xl border transition-all ${
                          isSelected ? 'bg-indigo-50/40 border-indigo-400' : 'bg-gray-50 border-gray-200'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="font-fredoka font-bold text-xs text-gray-900 flex-1">
                            Câu {idx + 1}: {q.text}
                          </div>
                          <button
                            onClick={() => handleToggleQuestion(q.id)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-fredoka font-bold transition-all cursor-pointer shrink-0 ${
                              isSelected 
                                ? 'bg-indigo-600 text-white' 
                                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-100'
                            }`}
                          >
                            {isSelected ? '✓ Đã chọn' : '+ Chọn câu này'}
                          </button>
                        </div>

                        {q.options && (
                          <div className="grid grid-cols-2 gap-1.5 mt-2">
                            {q.options.map((opt, oIdx) => (
                              <div
                                key={oIdx}
                                className={`text-[11px] px-2 py-1 rounded-lg border ${
                                  opt === q.answer 
                                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold' 
                                    : 'bg-white text-gray-600 border-gray-200'
                                }`}
                              >
                                {String.fromCharCode(65 + oIdx)}. {opt}
                              </div>
                            ))}
                          </div>
                        )}

                        {q.explanation && (
                          <div className="text-[10px] text-gray-500 mt-2 italic">
                            💡 {q.explanation}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between gap-3">
              <button
                onClick={() => setActiveTopicDetail(null)}
                className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 font-fredoka font-bold text-xs rounded-xl cursor-pointer"
              >
                Đóng
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    handleQuickPlayTopic(activeTopicDetail, 'quiz');
                    setActiveTopicDetail(null);
                  }}
                  className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-fredoka font-bold text-xs rounded-xl shadow-md cursor-pointer flex items-center gap-2"
                >
                  <Gamepad2 className="w-4 h-4" />
                  <span>Bắt Đầu Trò Chơi Ngay 🚀</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* GAME LAUNCHER SELECTOR MODAL */}
      {isGameLauncherOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden border border-indigo-100 animate-scale-in">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-800 via-indigo-800 to-blue-800 text-white p-6 relative">
              <button
                onClick={() => setIsGameLauncherOpen(false)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2.5 py-0.5 bg-amber-400 text-amber-950 font-fredoka font-black text-xs rounded-md">
                  CHỌN TRÒ CHƠI LỚP HỌC
                </span>
                <span className="text-xs text-indigo-200">
                  {pendingGameQuestions.length} câu hỏi đã nạp
                </span>
              </div>
              <h2 className="text-xl font-extrabold font-fredoka text-white">
                🎮 Khởi Chạy Trò Chơi Học Tập
              </h2>
              <p className="text-xs text-indigo-200 mt-1">
                Chọn chế độ trò chơi phù hợp với tiết dạy để thu hút học sinh tham gia hào hứng:
              </p>
            </div>

            {/* Game Modes Grid */}
            <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto">
              {gameModeCatalog.map((gm) => (
                <button
                  key={gm.id}
                  onClick={() => handleLaunchGameMode(gm.id as GameType)}
                  className="p-4 rounded-2xl border border-gray-200 hover:border-indigo-400 bg-white hover:bg-indigo-50/30 transition-all text-left flex items-start gap-3.5 group cursor-pointer hover:shadow-md hover:scale-[1.02]"
                >
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${gm.color} text-white flex items-center justify-center text-2xl shadow-sm shrink-0 group-hover:rotate-6 transition-transform`}>
                    {gm.icon}
                  </div>
                  <div className="flex-1">
                    <div className="font-fredoka font-bold text-sm text-gray-900 group-hover:text-indigo-600 transition-colors">
                      {gm.name}
                    </div>
                    <div className="text-xs text-gray-500 mt-0.5 leading-snug">
                      {gm.desc}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
              <button
                onClick={() => setIsGameLauncherOpen(false)}
                className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 font-fredoka font-bold text-xs rounded-xl cursor-pointer"
              >
                Hủy bỏ
              </button>
              <div className="text-xs text-gray-500 font-fredoka">
                * Học sinh có thể nhận điểm thưởng & nâng cấp thú cưng ảo khi chơi!
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
